

import UIKit

class TimesTableViewCell: UITableViewCell {
    
    @IBOutlet weak var vwMain: UIView!
    @IBOutlet weak var vwTimes: UIView!
    @IBOutlet weak var vwAddNew: UIView!
    @IBOutlet weak var btnAddTime: UIButton!
    @IBOutlet weak var btnSaveTime: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.vwTimes.isHidden = true
        self.vwAddNew.isHidden = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
