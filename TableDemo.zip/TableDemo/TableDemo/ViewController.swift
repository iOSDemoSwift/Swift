

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tblCalender: UITableView!
    
    private var numSelect = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    private func setupUI() {
        tblCalender.register(UINib(nibName: "TimesTableViewCell", bundle: nil), forCellReuseIdentifier: "TimesTableViewCell")
        tblCalender.delegate = self
        tblCalender.dataSource = self
    }
    
    @objc func onBtnHeaderCellChecked(_ sender: UIButton) {
        let i = sender.tag
        
        if arrRegular[i].check == 1 {
            numSelect = -1
            arrRegular[i].check = 0
        } else {
            numSelect = i
            arrRegular[i].check = 1
        }
        
        tblCalender.reloadData()
    }
    
    @objc func onBtnSaveTime(_ sender: UIButton) {
        let i = numSelect
        let j = sender.tag
        
        arrRegular[i].times[j]["isDone"] = 1
        
        tblCalender.reloadData()
    }
    
    @objc func onBtnAddNewTime(_ sender: UIButton) {
        let i = numSelect
        let j = arrRegular[i].times.count - 1
        
        arrRegular[i].times.insert(dicTime, at: j)
        
        tblCalender.reloadData()
    }

}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    //Sections
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return arrRegular.count
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerCell = Bundle.main.loadNibNamed("HeaderTableViewCell", owner: self, options: nil)?.first as! HeaderTableViewCell
        
        let header = arrRegular[section]
        headerCell.lblTitle.text = header.section
        
        if header.check == 1 {
            headerCell.imgCheck.image = #imageLiteral(resourceName: "ic_box_selected_serv")
        } else {
            headerCell.imgCheck.image = #imageLiteral(resourceName: "ic_box_unselected_serv")
        }
        
        headerCell.btnSelect.tag = section
        headerCell.btnSelect.addTarget(self, action: #selector(onBtnHeaderCellChecked(_:)), for: .touchUpInside)
        
        return headerCell
    }
    
    //Rows
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if numSelect == -1 {
            return 0
        } else if numSelect == indexPath.section {
            let arrTimes = arrRegular[indexPath.section].times
            let lastIndex = arrTimes.count - 1
            
            if lastIndex == indexPath.row {
                return 100
            } else if lastIndex != indexPath.row {
                return 130
            }
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let timeLine = arrRegular[section].times
        return timeLine.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TimesTableViewCell") as! TimesTableViewCell
        
        let arrTimes = arrRegular[indexPath.section].times
        
        let lastIndex = arrTimes.count - 1
        if lastIndex == indexPath.row {
            cell.vwAddNew.isHidden = false
            let title = arrTimes[lastIndex]["add"] as! String
            cell.btnAddTime.setTitle(title, for: .normal)
        } else if lastIndex != indexPath.row {
            cell.vwTimes.isHidden = false
            cell.vwAddNew.isHidden = true
            
            if arrTimes[indexPath.row]["isDone"] as! Int == 1 {
                cell.btnSaveTime.backgroundColor = .red
            }
        }
        
        cell.btnSaveTime.tag = indexPath.row
        cell.btnSaveTime.addTarget(self, action: #selector(onBtnSaveTime(_:)), for: .touchUpInside)

        cell.btnAddTime.addTarget(self, action: #selector(onBtnAddNewTime(_:)), for: .touchUpInside)
        return cell
    }
}
