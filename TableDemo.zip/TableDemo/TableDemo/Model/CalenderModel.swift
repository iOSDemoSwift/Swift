

import Foundation
import UIKit

class RegularModel {
    var section: String
    var check: Int
    var times: [[String: Any]]
    
    init(header: String, check: Int, times: [[String: Any]]) {
        self.section = header
        self.check = check
        self.times = times
    }
}


let dicTime: [String: Any] = ["start": "10:00am", "end": "11:30am", "isDone": 0]

let times: [[String: Any]] = [dicTime,
                              ["add": "Add New Time Shift"]]

let arrRegular: [RegularModel] = [
    RegularModel(header: "Mondays", check: 0, times: times),
    RegularModel(header: "Tusdays", check: 0, times: times),
    RegularModel(header: "Wendsdays", check: 0, times: times),
    RegularModel(header: "Tursdays", check: 0, times: times),
    RegularModel(header: "Fridays", check: 0, times: times),
    RegularModel(header: "Saturdays", check: 0, times: times),
    RegularModel(header: "Sundays", check: 0, times: times)
]
