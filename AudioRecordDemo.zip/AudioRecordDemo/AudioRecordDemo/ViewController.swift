//
//  ViewController.swift
//  AudioRecordDemo
//https://github.com/harshalrj25/audioStreamDemo/blob/master/audioStreamDemo/PlayerViewController.swift

import UIKit
import AVFoundation

class ViewController: UIViewController {

    @IBOutlet weak var btnAttach: UIButton!
    @IBOutlet weak var btnSend: UIButton!
    @IBOutlet weak var btnRecord: UIButton!
    @IBOutlet weak var vwRecord: UIView!
    @IBOutlet weak var imgRecMic: UIImageView!
    @IBOutlet weak var lblTime: UILabel!
    
    var recordingSession: AVAudioSession!
    var audioRecorder: AVAudioRecorder!
    var audioPlayer:AVAudioPlayer!
    var timerForRecord = Timer()
    
    var isRecordStart: Bool = false
    var recordCount: Double = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        vwRecord.isHidden = true
        isRecordStart = false
        btnRecord.isSelected = false
        btnSend.isSelected = false
        self.setupView()
    }
    
    func setupView() {
        recordingSession = AVAudioSession.sharedInstance()
        
        do {
            try recordingSession.setCategory(.playAndRecord, mode: .default)
            try recordingSession.setActive(true)
            recordingSession.requestRecordPermission() { allowed in
                DispatchQueue.main.async {
                    if allowed {
                        
                    } else {
                        // failed to record
                    }
                }
            }
        } catch {
            // failed to record
        }
    }
    
    func startRecording() {
        let audioFilename = getFileURL()
        
        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 12000,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]
        
        do {
            audioRecorder = try AVAudioRecorder(url: audioFilename, settings: settings)
            audioRecorder.delegate = self
            audioRecorder.record()
            
            btnRecord.setImage(#imageLiteral(resourceName: "stop"), for: .normal)
            vwRecord.isHidden = false
            runRecordTimer()
        } catch {
            finishRecording(success: false)
        }
    }
    
    func finishRecording(success: Bool) {
        audioRecorder.stop()
        audioRecorder = nil
        btnRecord.setImage(#imageLiteral(resourceName: "voice-mic"), for: .normal)
        vwRecord.isHidden = true
    }
    
    func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    
    func getFileURL() -> URL {
        let path = getDocumentsDirectory().appendingPathComponent("recording.m4a")
        return path as URL
    }
    
    func runRecordTimer() {
        timerForRecord = Timer()
        lblTime.text = "0:00"
        
        timerForRecord = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateRecordingCount), userInfo: nil, repeats: true)
    }
    
    @objc func updateRecordingCount() {
        recordCount += 0.01
        lblTime.text = String(format: "%.2f", recordCount).replacingOccurrences(of: ".", with: ":")
    }
    
    func stopRecordtimer() {
        timerForRecord.invalidate()
        timerForRecord = Timer()
    }

    func preparePlayer() {
        var error: NSError?
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: getFileURL() as URL)
        } catch let error1 as NSError {
            error = error1
            audioPlayer = nil
        }
        
        if let err = error {
            print("AVAudioPlayer error: \(err.localizedDescription)")
        } else {
            audioPlayer.delegate = self
            audioPlayer.prepareToPlay()
            audioPlayer.volume = 10.0
        }
    }
    
    @IBAction func onBtnAttach(_ sender: UIButton) {
        guard let data = try? Data(contentsOf: getFileURL() as URL) else {
            return
        }
        
        print(data.count)
    }
    
    @IBAction func onBtnSend(_ sender: UIButton) {
        btnSend.isSelected = !btnSend.isSelected
        
        if btnSend.isSelected {
            preparePlayer()
            audioPlayer.play()
        } else {
            audioPlayer.stop()
        }
    }
    
    @IBAction func onBtnCancel(_ sender: UIButton) {
        finishRecording(success: true)
    }
    
    @IBAction func onBtnRecord(_ sender: UIButton) {
        btnRecord.isSelected = !btnRecord.isSelected
        
        if btnRecord.isSelected {
            //Start
            isRecordStart = true
            startRecording()
        } else {
            //stop
            stopRecordtimer()
            isRecordStart = false
            finishRecording(success: true)
        }
    }
}

extension ViewController: AVAudioRecorderDelegate, AVAudioPlayerDelegate {
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if !flag {
            finishRecording(success: false)
        }
    }
    
    func audioRecorderEncodeErrorDidOccur(_ recorder: AVAudioRecorder, error: Error?) {
        print("Error while recording audio \(error!.localizedDescription)")
    }
    
    //player
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        btnRecord.isSelected = false
    }
    
    func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        print("Error while playing audio \(error!.localizedDescription)")
    }
}
