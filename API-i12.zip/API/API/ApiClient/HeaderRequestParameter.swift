//
//  HeaderRequest.swift



import Foundation

class HeaderRequestParameter {
    var parameters = [String : String]()
    
    static let xAccessToken = "x-access-token"
    
    init() {
        if(AppPrefsManager.shared.isUserLoggedIn()) {
//            addParameter(key: HeaderRequestParameter.xAccessToken, value: AppPrefsManager.shared.getUserToken())
            addParameter(key: HeaderRequestParameter.xAccessToken, value: AppPrefsManager.shared.getSessionId())
        }
    }
    
    func addJsonContentType() {
        addParameter(key: "Content-Type", value: "application/json")
    }
    
    func removeJsonContentType() {
        parameters["Content-Type"] = nil
    }

    func addParameter(key: String, value: String) {
        parameters[key] = value
    }
}
