//
//  MapApiClient.swift


import Foundation

final class MapApiClient {
    
    var baseURL: String
    
    init(baseURL: String) {
        self.baseURL = baseURL
    }
    
    func request<Response: Decodable>(type: Response.Type, path: String, method: HTTPMethod = .get, parameters: [String : Any], completion: @escaping (Swift.Result<Response, Error>) -> Void) {
        
        guard let request = createRequest(path: path, parameter: parameters) else {
            completion(.failure(CustomError.other))
            return
        }
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            guard error == nil else {
                completion(.failure(error!))
                return
            }
            
            guard let data = data, let response = response as? HTTPURLResponse, (200 ..< 300) ~= response.statusCode else {
                completion(.failure(CustomError.other))
                return
            }
            
            do {
                
                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase
                
                //let resp = try JSONSerialization.jsonObject(with: data, options: [])
                //DLog("Response: ", resp)
                
                let response = try decoder.decode(type, from: data)
                DispatchQueue.main.async {
                    completion(.success(response))
                }
                
            } catch let error {
                completion(.failure(error))
            }
            
        }
        
        task.resume()
    }
    
    private func createRequest(path: String, parameter: [String : Any]) -> URLRequest? {
        guard var components = URLComponents(string: baseURL + path) else {
            return nil
        }
        
        components.queryItems = parameter.map { param -> URLQueryItem in
            return URLQueryItem(name: param.key, value: param.value as? String)
        }
        
        return URLRequest(url: components.url!)
    }
}

public enum CustomError: Error, LocalizedError {
    
    case other
    
    public var errorDescription: String? {
        switch self {
        case .other: return NSLocalizedString("Request not created", comment: "")
        }
    }
}

public enum HTTPMethod: String {
    case options = "OPTIONS"
    case get     = "GET"
    case head    = "HEAD"
    case post    = "POST"
    case put     = "PUT"
    case patch   = "PATCH"
    case delete  = "DELETE"
    case trace   = "TRACE"
    case connect = "CONNECT"
}
