//
//  ApiManager.swift



import Foundation
import Alamofire

class ApiManager {
    
    class func callApi(apiURL: String, method: Alamofire.HTTPMethod, parameters: [String: Any]? = nil, headers: [String: String]? = nil, parameterEncoding: ParameterEncoding, success successBlock:@escaping ((Any?, Int?) -> Void), failure failureBlock: ((Error, Int?) -> Bool)?) -> DataRequest {
        
        var finalParameters = [String: Any]()
        
        if parameters != nil {
            finalParameters = parameters!
        }
        
        DLog("parameters = ", finalParameters)
        DLog("apiURL = ", apiURL)
                
        return Alamofire.request(apiURL, method: method, parameters: finalParameters, encoding: parameterEncoding, headers: headers)
            .responseString { response in
                
                DLog("Response String: \(String(describing: response.result.value))")
            }
            .responseJSON { response in
                
                DLog("Response Error: ", response.result.error)
                DLog("Response JSON: ", response.result.value)
                DLog("response.request: ", response.request?.allHTTPHeaderFields)
                DLog("Response Status Code: ", response.response?.statusCode)
                
                DispatchQueue.main.async {
                    if response.result.error == nil {
                        let responseObject = response.result.value
                        
                        /*if let status = responseObject as? [String : Any], (status["status"] as? String ?? "") == "3" {
                            AppDelegate.shared.logOutFromApplication()
                        }*/
                        successBlock(responseObject, response.response?.statusCode)
                        
                        if Utility.logoutSessionExpire(response: responseObject as Any, statusCode: response.response!.statusCode) {
                            //if required
                        }
                        
                    } else {
                        if failureBlock != nil && failureBlock!(response.result.error! as NSError, response.response?.statusCode) {
                            if let statusCode = response.response?.statusCode {
                                ApiManager.handleAlamofireHttpFailureError(statusCode: statusCode)
                            }
                        }
                    }
                }
        }
    }
    
    class func callApiWithUpload(apiURL: String, method: Alamofire.HTTPMethod, parameters: [String: Any]? = nil, fileDataParameters: [FileParameterRequest]? = nil, headers: [String: String]? = nil, success successBlock:@escaping ((Any?, Int?) -> Void), failure failureBlock: ((Error, Int?) -> Bool)?) {
        
        var finalParameters = [String: Any]()
        if parameters != nil {
            finalParameters = parameters!
        }
        
        DLog("parameters = ", finalParameters)
        DLog("apiURL = ", apiURL)
        
        return Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            multipartFormData.append("".data(using: String.Encoding.utf8)!, withName: "")
            
            for (key, value) in finalParameters {
                multipartFormData.append(String(describing: value).data(using: .utf8)!, withName: key)
            }
            
            if fileDataParameters != nil && (fileDataParameters?.count)! > 0 {
                for i in 0...(fileDataParameters!.count - 1) {
                    let dict = fileDataParameters![i].parameters
                    multipartFormData.append(dict["file_data"] as! Data, withName: dict["param_name"] as! String, fileName: dict["file_name"] as! String, mimeType: dict["mime_type"] as! String)
                }
            }
            
        }, to: apiURL, method: method, headers: headers, encodingCompletion: { (encodingResult) in
            switch encodingResult {
            case .success(let upload, _, _):
                
                upload.responseString { response in
                    
                    DLog("Response String: \(String(describing: response.result.value))")
                }
                
                upload.responseJSON { response in
                    
                    DLog("Response Error: ", response.result.error)
                    DLog("Response JSON: ", response.result.value)
                    DLog("response.request: ", response.request?.allHTTPHeaderFields)
                    DLog("Response Status Code: ", response.response?.statusCode)
                    
                    DispatchQueue.main.async {
                        if(response.response?.statusCode == 401)
                        {
                        }
                        else if (response.result.error == nil) {
                            let responseObject = response.result.value
                            //let response = responseObject as! [String: AnyObject]
                            
                            /*if (response["status"] as? NSNumber)?.intValue == ResponseFlag.sessionExpired
                             {
                             let baseVc = BaseViewController()
                             baseVc.logoutUser()
                             
                             }*/
                            
                            successBlock(responseObject, response.response?.statusCode)
                        } else {
                            if failureBlock != nil && failureBlock!(response.result.error! as NSError, response.response?.statusCode) {
                                if let statusCode = response.response?.statusCode {
                                    ApiManager.handleAlamofireHttpFailureError(statusCode: statusCode)
                                }
                            }
                        }
                    }
                    
                }
            case .failure(let encodingError):
                
                Utility.showMessageAlert(title: "Error", andMessage: "\(encodingError)", withOkButtonTitle: "OK")
                
            }
        })
        
    }
    
    class func handleAlamofireHttpFailureError(statusCode: Int) {
        switch statusCode {
        case NSURLErrorUnknown:
            
            Utility.showMessageAlert(title: "Error", andMessage: "Ooops!! Something went wrong, please try after some time!", withOkButtonTitle: "OK")
            
        case NSURLErrorCancelled:
            
            break
        case NSURLErrorTimedOut:
            
            Utility.showMessageAlert(title: "Error", andMessage: "The request timed out, please verify your internet connection and try again.", withOkButtonTitle: "OK")
            
        case NSURLErrorNetworkConnectionLost:
            //displayAlert("Error", andMessage: NSLocalizedString("network_lost", comment: ""))
            break
            
        case NSURLErrorNotConnectedToInternet:
            //displayAlert("Error", andMessage: NSLocalizedString("internet_appears_offline", comment: ""))
            break
            
        default:
            
            Utility.showMessageAlert(title: "Error", andMessage: "Ooops!! Something went wrong, please try after some time!", withOkButtonTitle: "OK")
            
        }
    }
    
    class func isNetworkReachable() -> Bool {
        return NetworkReachabilityManager(host: "www.apple.com")?.isReachable ?? false
    }
    
    public static let apiSessionManager: SessionManager = {
        let configuration = URLSessionConfiguration.default
        configuration.httpAdditionalHeaders = SessionManager.defaultHTTPHeaders
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 300
        configuration.timeoutIntervalForResource = 300
        
        return SessionManager(configuration: configuration)
    }()
}
