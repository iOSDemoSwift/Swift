//
//  ApiParameter.swift


import Foundation

class ParameterRequest {

    var parameters = [String: Any]()

    static let email                = "email"
    static let password             = "password"
    static let full_name            = "full_name"
    static let confirm_password     = "confirm_password"
    static let new_password         = "new_password"
    static let device_type          = "device_type"
    static let device_token         = "device_token"
    static let fcm_token            = "fcm_token"
    static let device_id            = "device_id"
    static let social_id            = "social_id"
    static let social_type          = "social_type"
    static let profile_pic          = "profile_pic"
    static let status               = "status"
    static let type                 = "type"
    static let user_id              = "user_id"
    static let active               = "active"
 
    
    /*init(){
        addParameter(key: ParameterRequest.device_type, value: "ios")
        addParameter(key: ParameterRequest.device_token, value: AppPrefsManager.shared.getFcmToken())
        addParameter(key: ParameterRequest.device_id, value: Utility.getAppUniqueId())
    }*/
    
    func addParameter(key: String, value: Any?) {
        parameters[key] = value
    }
    
}

class FileParameterRequest {
    var parameters = [String: Any]()
    
    static let file_data = "file_data"
    static let param_name = "param_name"
    static let file_name = "file_name"
    static let mime_type = "mime_type"
    
    init(){}
    
    func addParameter(key: String, value: Any?) {
        parameters[key] = value
    }
}
