//
//  GlobalConstants.swift


import Foundation
import UIKit
import CoreLocation

//MARK: - Global variables
var isDevelopmentMode       =   true
var enableProductionApi     =   false
let DeviceLoginType         =   "ios"
var radius                  =   1050000
let notAuthenticate         =   "You are not authenticated person."
let noDataFound             =   "No data found"

//Location
var latitude                = String()
var longitude               = String()

//MARK:- Last Screen Store
var lastUIScreen = String()
var isLastScreen = false
var PostID = 0

//MARK:- Firebase
var firPassword = "1" + "2" + "3" + "4" + "5" + "6" + "7"

//MARK: -  FontName
enum FontName: String {
    case rubikBold      = "rubik-bold"
    case rubikMedium    = "rubik-medium"
    case rubikItalic    = "rubik-italic"
    case rubikRegular   = "rubik-regular"
}

let APP_REGULAR_FONT    = FontName.rubikRegular
let APP_ITALIC_FONT     = FontName.rubikItalic
let APP_BOLD_FONT       = FontName.rubikBold
let APP_MEDIUM_FONT     = FontName.rubikMedium

//MARK:- SelectTab
var selectTabIndex = 0

//MARK:- Notification Name
let SelectHomeTabNotificationName = Notification.Name("SelectHomeTabNotificationName")
let SelectReqAndSolTabNotificationName = Notification.Name("SelectReqAndSolTabNotificationName")

//MARK:- Keychain
let FaceIDLogin = "faceIDLogin"
let isFaceIDLogin = "isFaceIDLogin"

//MARK: - Enums
enum SortBy: String {    
    case newest    =   "Newest"
    case closest   =   "Closest"
}

enum LoginType: String {
    case normal     = "normal"
    case facebook   = "facebook"
}

enum UIScreenName: String {
    case postLive  = "PostLiveInfo"
}

struct ResponseStatus {
    static let success  = 1
    static let fail     = 0
}

//MARK:- UserDetaults Key
let KEY_LOGIN = "login"

//MARK: - API
struct API {
    //Demo
//   static var BASE_URL = ""
    
    //Live
    static var BASE_URL = ""
    
    static let LOGIN                      =   BASE_URL + "login"
    static let REGISTER                   =   BASE_URL + "register"
    
}
