//
//  StringConstants.swift


import Foundation

struct StringConstants {
    static let ENTER_FULL_NAME              = "Enter Full name."
    static let ENTER_PASSWORD               = "Enter password"
    static let MINIMUM_PASSWORD_REQUIRED    = "The password must be at least 6 characters."
    static let ENTER_EMAIL                  = "Enter email address."
    static let ENTER_VALID_EMAIL            = "Enter valid email"
    static let ENTER_PHONE_NUMBER           = "Enter mobile number."
    static let MINIMUM_PHONE_NUM_REQUIRED   = "Min. 10 character is required for mobile number."
    
    static let ENTER_NEW_PASSWORD           = "Enter new password."
    static let ENTER_NEW_CONFIRM_PASSWORD   = "Re-enter new password."
    static let ENTER_NEW_AND_CONFIRM_PASSWORD_NOT_MATCH   = "New password and Confirm password does not match."
    
    static let SELECT_IMAGE_REQUIRED        = "Add Image"
    static let ENTER_POST_TITLE_REQUIRED    = "Enter headline"
    static let SELECT_CATEGORY_REQUIRED     = "Select a category"
    static let ENTER_DISCRIBE_REQUIRED      = "Enter describtion"
    static let SELECT_LOCATION_REQUIRED     = "Select a location"
    static let SELECT_RADIUS_REQUIRED       = "Select a radius"
    
    static let DATA_NOT_FOUND               = "Data Not Found."
    
}
