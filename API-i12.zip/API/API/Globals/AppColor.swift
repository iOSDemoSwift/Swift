//
//  AppColor.swift


import Foundation
import UIKit

struct AppColor {
    static let DARK_BLUE        = #colorLiteral(red: 0.1411764706, green: 0.1764705882, blue: 0.4274509804, alpha: 1)
    static let DARK_PURPLE      = #colorLiteral(red: 0.4392156863, green: 0.1490196078, blue: 0.5294117647, alpha: 1)
    static let LIGHT_ORANGE     = #colorLiteral(red: 1, green: 0.5764705882, blue: 0.4392156863, alpha: 1)
    static let BORDER_COLOR     = #colorLiteral(red: 0.9254901961, green: 0.937254902, blue: 0.9529411765, alpha: 1)
    static let LIGHT_GRAY       = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
    static let DARK_GRAY        = #colorLiteral(red: 0.4274509804, green: 0.4470588235, blue: 0.4705882353, alpha: 1)
    static let CHAT_LIGHTPINK_COLOR = #colorLiteral(red: 0.9490196078, green: 0.937254902, blue: 0.968627451, alpha: 1)
    static let CHAT_LIGHTGREY_COLOR = #colorLiteral(red: 0.9568627451, green: 0.9607843137, blue: 0.9647058824, alpha: 1)
}

//static let pinkColor = UIColor(red: 242/255, green: 239/255, blue: 247/255, alpha: 1)
//static let lightGreyColor = UIColor(red: 244/255, green: 245/255, blue: 246/255, alpha: 1)
