//
//  Utility.swift

import Foundation
import UIKit
import CoreLocation

class Utility {
    
    //MARK: - Variables
    static let shared = Utility()
    
    var enableLog = true
    var appDelegate = UIApplication.shared.delegate as! AppDelegate
    var loaderCount = 0
    
    //MARK: - Functions
    class func isLogEnable() -> Bool {
        return self.shared.enableLog
    }
    
    class func enableLog() {
        self.shared.enableLog = true
    }
    
    class func disableLog() {
        self.shared.enableLog = false
    }
    
    class func appDelegate() -> AppDelegate {
        return self.shared.appDelegate
    }
    
    class func windowMain() -> UIWindow? {
        return self.appDelegate().window
    }
    
    class func rootViewControllerMain() -> UIViewController? {
        return self.windowMain()?.rootViewController        
    }
    
    class func applicationMain() -> UIApplication {
        return UIApplication.shared
    }
    
    class func getMajorSystemVersion() -> Int {
        let systemVersionStr = UIDevice.current.systemVersion   //Returns 7.1.1
        let mainSystemVersion = Int((systemVersionStr.split(separator: "."))[0])
        
        return mainSystemVersion!
    }
    
    class func getAppUniqueId() -> String
    {
        let uniqueId: UUID = UIDevice.current.identifierForVendor! as UUID
        
        return uniqueId.uuidString
    }
    
    class func showMessageAlert(title: String, andMessage message: String, withOkButtonTitle okButtonTitle: String)
    {
        let alertWindow: UIWindow = UIWindow(frame: UIScreen.main.bounds)
        alertWindow.rootViewController = UIViewController()
        alertWindow.windowLevel = UIWindow.Level.alert + 1
        alertWindow.makeKeyAndVisible()
        
        let alertController: UIAlertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: okButtonTitle, style: .default, handler: { (action) -> Void in
            
            alertWindow.isHidden = true
            
        }))
        
        alertWindow.rootViewController?.present(alertController, animated: true, completion: nil)
    }    
    
    class func getAddressFromLatLong(lat: String, long: String, completion: @escaping (_ address: String) -> Void) {
        var address = String()
        
        let geoCoder = CLGeocoder()
        let location = CLLocation(latitude: Double(lat) as! CLLocationDegrees, longitude: Double(long) as! CLLocationDegrees)
        
        do {
            geoCoder.reverseGeocodeLocation(location) { (placemarks, error) in
//                var placeMark: CLPlacemark!
//                placeMark = placemarks?[0]
                
                guard let placeMark: CLPlacemark = placemarks?.first, error == nil else {
                    completion("")
                    return
                }
                
                // Country
                if let country = placeMark.country {
                    print("Country :- \(country)")
                    if let state = placeMark.locality {
                        print("State :- \(state)")
                        
                        address = "\(state), \(country)"
                        completion(address)
                    } else {
                        address = "\(country)"
                        completion(address)
                    }
                } else {
                    completion("")
                }
            }
        } catch let error {
            completion("")
            DLog(error.localizedDescription)
        }        
    }
    
    class func getLocationFromPostalCode(postalCode : String, completion: @escaping (_ address: String, _ location: CLLocation, _ errorMessage: String) -> Void) {
        let geocoder = CLGeocoder()
        
        do {
            geocoder.geocodeAddressString(postalCode) {
                (placemarks, error) -> Void in
                // Placemarks is an optional array of type CLPlacemarks, first item in array is best guess of Address
                
                if let placemark = placemarks?[0] {
                    
                    if placemark.postalCode == postalCode {
                        let address = "\(placemark.locality ?? ""), \(placemark.country ?? "")"
                        let location = placemark.location
                        completion(address, location!, "")
                    }
                    else{
                        completion("", CLLocation(), "Please enter valid zipcode")
                    }
                } else {
                    completion("", CLLocation(), "Please enter valid zipcode")
                }
            }
        } catch let error {
            completion("", CLLocation(), "")
            DLog(error.localizedDescription)
        }
    }
    
    class func imageToData(_ imagePath: String) -> Data {
        var imageData = Data()
        
        do {
            imageData = try Data(contentsOf: URL(string:  imagePath)!)
        } catch let error {
            DLog("ImageToData: ", error.localizedDescription)
        }
        
        return imageData
    }
    
    class func getUrgencyPriority(urgency: Int) -> String {
        var priority = String()
        
        if urgency >= 0 && urgency <= 4 {
            priority = "Low Priority"
        } else if urgency > 4 && urgency <= 9 {
            priority = "Medium Priority"
        } else if urgency > 9 && urgency <= 24 {
            priority = "High Priority"
        } else if urgency > 24 && urgency <= 25 {
            priority = "Highest Priority"
        }
        
        return priority
    }
    
    class func dateString() -> String {
        let date = Date()
        let dateFormatter = DateFormatter()
        let enUSPosixLocale = Locale(identifier: "en_US_POSIX")
        dateFormatter.calendar = Calendar(identifier: .iso8601)
        dateFormatter.locale = enUSPosixLocale
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "yyMMdd_HHmmss"
        
        let iso8601String = dateFormatter.string(from: date as Date)
        
        return iso8601String
    }
    
    class func convertString(intoDate strDate: String?) -> Date? {
        let formatter = DateFormatter()
        let timeZone = NSTimeZone(name: "UTC")
        formatter.timeZone = timeZone as TimeZone?
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return formatter.date(from: strDate ?? "")
    }
    
    class func convertDate(intoString date: Date?) -> String? {
        let formatter = DateFormatter()
        let timeZone = NSTimeZone(name: "UTC")
        formatter.timeZone = timeZone as TimeZone?
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        if let date = date {
            return formatter.string(from: date)
        }
        
        return nil
    }
    
    class func convertCurrentDateToUTC() -> Date {
        let strDate = Utility.convertDate(intoString: Date())
        let date = Utility.convertString(intoDate: strDate)!
        
        return date
    }
    
    class func removeDash(num: Int) -> Int {
        var newNumber = Int()
        String(num).contains("-") ? (newNumber = num * -1) : (newNumber = num)
        
        return newNumber
    }
    
    class func timeForChat(timeStamp: Double) -> String {
        var time = String()
        
        let timestampDate = Date(timeIntervalSince1970: timeStamp)
        
        let dateFormatter = DateFormatter()
        //format to display for timestamp
        dateFormatter.dateFormat = "hh:mm a"
        time = dateFormatter.string(from: timestampDate)
        
        return time
    }
    
    class func getStringSplitArray(str: String, separator: Character) -> String {
        let arr = str.split(separator: separator)
        let strName: String = String(arr[arr.count - 1])
        
        return strName
    }
    
    class func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }

    class func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size
        
        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio, height: size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
    
    class func logoutSessionExpire(response: Any, statusCode: Int) -> Bool {
        
        if statusCode == 400 {
            if let responseObj = response as? [String : Any] {
                let message = responseObj["message"] as? String ?? ""
                
                if message == notAuthenticate {
                    return true
                }
            }
        }
        
        return false
    }
}



// MARK: - All UIApplication extensions
extension UIApplication {
    var isKeyboardPresented: Bool {
        if let keyboardWindowClass = NSClassFromString("UIRemoteKeyboardWindow"), self.windows.contains(where: { $0.isKind(of: keyboardWindowClass) }) {
            return true
        } else {
            return false
        }
    }
}

// MARK: - All UIImage Extensions
extension UIImage {
    
    func tintWithColor(_ color:UIColor) -> UIImage {
        
        UIGraphicsBeginImageContextWithOptions(self.size, false, UIScreen.main.scale);
        //UIGraphicsBeginImageContext(self.size)
        let context = UIGraphicsGetCurrentContext()
        
        // flip the image
        context?.scaleBy(x: 1.0, y: -1.0)
        context?.translateBy(x: 0.0, y: -self.size.height)
        
        // multiply blend mode
        context?.setBlendMode(.multiply)
        
        let rect = CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height)
        context?.clip(to: rect, mask: self.cgImage!)
        color.setFill()
        context?.fill(rect)
        
        // create uiimage
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }
}

//MARK: - Structs
struct IOS_VERSION
{
    static var IS_IOS7 = Utility.getMajorSystemVersion() >= 7 && Utility.getMajorSystemVersion() < 8
    static var IS_IOS8 = Utility.getMajorSystemVersion() >= 8 && Utility.getMajorSystemVersion() < 9
    static var IS_IOS9 = Utility.getMajorSystemVersion() >= 9 && Utility.getMajorSystemVersion() < 10
    static var IS_IOS10 = Utility.getMajorSystemVersion() >= 10 && Utility.getMajorSystemVersion() < 11
    static var IS_IOS11 = Utility.getMajorSystemVersion() >= 11 && Utility.getMajorSystemVersion() < 12
    static var IS_IOS12 = Utility.getMajorSystemVersion() >= 12 && Utility.getMajorSystemVersion() < 13
    static var IS_IOS13 = Utility.getMajorSystemVersion() >= 13
}

struct ScreenSize
{
    static let SCREEN_BOUNDS = UIScreen.main.bounds
    static let SCREEN_WIDTH = UIScreen.main.bounds.size.width
    static let SCREEN_HEIGHT = UIScreen.main.bounds.size.height
    static let SCREEN_MAX_LENGTH = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    static let SCREEN_MIN_LENGTH = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
}

struct DeviceType
{
    static let IS_IPHONE = UIDevice.current.userInterfaceIdiom == .phone
    static let IS_IPAD = UIDevice.current.userInterfaceIdiom == .pad
    
    static let IS_IPHONE_4_OR_LESS =  IS_IPHONE && ScreenSize.SCREEN_MAX_LENGTH < 568.0
    static let IS_IPHONE_5 = IS_IPHONE && ScreenSize.SCREEN_MAX_LENGTH == 568.0
    static let IS_IPHONE_6 = IS_IPHONE && ScreenSize.SCREEN_MAX_LENGTH == 667.0
    static let IS_IPHONE_6P = IS_IPHONE && ScreenSize.SCREEN_MAX_LENGTH == 736.0
    static let IS_IPHONE_X = IS_IPHONE && ScreenSize.SCREEN_MAX_LENGTH == 812.0 // X, Xs, 11 Pro
    static let IS_IPHONE_X_MAX = IS_IPHONE && ScreenSize.SCREEN_MAX_LENGTH == 896.0 // Xr, 11, 11 Pro Max, Xs Max
    static let IS_IPHONE_LESS_THAN_6 =  IS_IPHONE && ScreenSize.SCREEN_MAX_LENGTH < 667.0
    static let IS_IPHONE_LESS_THAN_OR_EQUAL_6 =  IS_IPHONE && ScreenSize.SCREEN_MAX_LENGTH <= 667.0
}
