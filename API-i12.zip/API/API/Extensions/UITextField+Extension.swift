//
//  UITextField+Extension.swift


import UIKit
import Foundation

extension UITextField {
    
    public func addLeftPadding(padding: CGFloat) {
        let tempView = UIView()
        tempView.frame = CGRect(x: 0, y: 0, width: padding, height: self.frame.height)
        
        self.leftView = tempView
        self.leftViewMode = .always
    }
    
    @IBInspectable public var placeHolderColor: UIColor? {
        get {
            return self.placeHolderColor
        }
        set {
            self.attributedPlaceholder = NSAttributedString(string: self.placeholder != nil ? self.placeholder! : "", attributes: [NSAttributedString.Key.foregroundColor: newValue!])
        }
    }
    
    public func addImageToRightSide(image: UIImage, width: CGFloat) {
        let imageView = UIImageView()
        imageView.frame = CGRect(x: 0, y: 0, width: width, height: self.frame.height)
        imageView.contentMode = .center
        imageView.image = image
        
        self.rightView = imageView
        self.rightViewMode = .always
    }
    
    func addImageToLeftSide(image: UIImage, width: CGFloat, height: CGFloat) {
        let imageView = UIImageView()
        imageView.frame.size = CGSize(width: height, height: width)
        imageView.contentMode = .scaleAspectFit
        imageView.image = image
        imageView.isUserInteractionEnabled = false
        
        let tempView = UIView(frame: CGRect(x: 3, y: 0, width: width, height: self.frame.height))
        
        tempView.addSubview(imageView)
        imageView.center = tempView.center
        tempView.isUserInteractionEnabled = false
        
        self.leftView = tempView
        self.leftViewMode = .always
    }
    
}
