//
//  UIColor+Extension.swift


import Foundation
import UIKit

extension UIColor {
    func image(size: CGSize = CGSize(width: 1, height: 1)) -> UIImage? {
        if #available(iOS 10.0, *) {
            return UIGraphicsImageRenderer(size: size).image { rendererContext in
                self.setFill()
                rendererContext.fill(CGRect(origin: .zero, size: size))
            }
        } else {
            let rect = CGRect(x: 0.0, y: 0.0, width: size.width, height: size.height)
            UIGraphicsBeginImageContext(rect.size)
            let context = UIGraphicsGetCurrentContext()
            
            context?.setFillColor(self.cgColor)
            context?.fill(rect)
            
            let image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            
            return image
        }
    }
}

struct Colors {
    
    static var lightPurple = UIColor(red:90/255, green: 50/255, blue: 120/255, alpha: 1)
    
    static var darkPurple = UIColor(red:70/255, green: 38/255, blue: 92/255, alpha: 1)
    
    static var white = UIColor(red:255/255, green: 255/255, blue: 255/255, alpha: 1)
    
    static var darkBlue = UIColor(red: 36/255, green: 39/255, blue: 47/255, alpha: 1)
    
    static var lighterDarkBlue = UIColor(red: 36/255, green: 41/255, blue: 50/255, alpha: 1)
    
    static var gray = UIColor(red: 50/255, green: 54/255, blue: 63/255, alpha: 1)
    
    static var offWhite = UIColor(red: 24/2557, green: 247/255, blue: 247/255, alpha: 1)
}
