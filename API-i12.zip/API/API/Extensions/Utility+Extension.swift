//
//  Utility+Extension.swift


import Foundation
import SDWebImage

extension Utility {
    func saveImage(url: URL, toCache: UIImage?) {
        guard let toCache = toCache else { return }
        
        let manager = SDWebImageManager.shared
        if let key = manager.cacheKey(for: url) {
            manager.imageCache.store(toCache, imageData: nil, forKey: key, cacheType: .all, completion: nil)
        }
    }
    
    static func imageFromMemory(for url: String) -> UIImage? {
        if let encoded = url.addingPercentEncoding(withAllowedCharacters: .urlFragmentAllowed),
            let url = URL(string: encoded) {
            let manager = SDWebImageManager.shared
            if let key: String = manager.cacheKey(for: url) {
                if let imageCache = manager.imageCache as? SDImageCache {
                    return imageCache.imageFromDiskCache(forKey: key)
                }
            }
        }
        return nil
    }
}
