//
//  UINavigationBar+Extension.swift


import Foundation
import UIKit

extension UINavigationBar {
    
    func applyNavigationGradient(colors : [UIColor]) {
        var frameAndStatusBar: CGRect = ScreenSize.SCREEN_BOUNDS
        frameAndStatusBar.size.height += 20
        
        setBackgroundImage(UIImage.gradientImageWith(size: frameAndStatusBar.size, colors: colors), for: .default)
    }
}
