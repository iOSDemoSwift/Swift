//
//  Data+Extensions.swift


import Foundation

extension Data {
    func convertToJsonObjet() -> Any? {
        do {
            return try JSONSerialization.jsonObject(with: self, options: JSONSerialization.ReadingOptions.mutableContainers)
        }
        catch let error {
            DLog("Error!! = \(error)")
        }
        return nil
    }
}
