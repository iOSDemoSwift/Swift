//
//  MapViewModel.swift


import Foundation
//import Alamofire

class MapViewModel {
    
    var apiClient = APIClient()
    var arrUserLocation = [Users]()
    
    //MARK:- Use Alamofire
   /* func callAPI(completion: @escaping (_ success: Bool, _ errorMessage: String) -> Void) {
        
        let url = URL(string: strUrlUserLocation)!
        let finalParameters = [String: Any]()
        let header: [String: Any] = ["Content-Type": "text/plain"]
        
        AF.request(url, method: .get, parameters: finalParameters, encoding: URLEncoding.default, headers: nil, interceptor: nil).response { (responseData) in
            
            guard let response = responseData.data else {
                completion(false, "")
                return
            }
            
            do {
                   
                    let json = try JSONSerialization.jsonObject(with: response, options: []) //data -> redable
                    let jsonData = try JSONSerialization.data(withJSONObject: json, options: .prettyPrinted) // redable -> data
                    self.arrUserLocation = try JSONDecoder().decode([Users].self, from: response) // data -> mapping model
                
                    if self.arrUserLocation.count > 0 {
                        completion(true, "")
                    } else {
                        completion(false, "")
                    }
                
            } catch {
                completion(false, error.localizedDescription)
            }
        }
    }*/
    
    
    //MARK:- Use URLSession
    func getUserLocation(completion: @escaping (_ success: Bool, _ errorMessage: String) -> Void) {
        
     /*   let header = ["Content-Type": "text/plain"]
        let url = URLComponents(string: strUrlUserLocation)
        
        APIClient.callDataTaskAPI(url: (url?.url)!, method: "GET", header: header) { (responseData, error, int) in
            
            guard let data = responseData else {
                completion(false, "")
                return
            }
            
            do {
                
                //if response.count > 0 {
                   // let jsonData = try JSONSerialization.data(withJSONObject: response, options: .prettyPrinted)
                    self.arrUserLocation = try JSONDecoder().decode([Users].self, from: data)
                    
                    if self.arrUserLocation.count > 0 {
                        completion(true, "")
                    } else {
                        completion(false, error!.localizedDescription)
                    }
               // }
                
            } catch {
                completion(false, error.localizedDescription)
            }
            
        }*/
        
    }
    
}
