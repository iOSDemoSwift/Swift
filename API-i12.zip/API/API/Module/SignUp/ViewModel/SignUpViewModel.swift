//
//  SignUpViewModel.swift


import Foundation

class SignupViewModel: BaseViewModel {
    
    // MARK: - Variable
    var signUpDataModel: SignUpModel?
    
    var fullName: String?
    var email: String?
    var password: String?
    
    var fileData: Data!
    
    // MARK: - Validations
    func validate() -> Bool {
        if fileData == nil {
            errorMessage = StringConstants.SELECT_IMAGE_REQUIRED
        } else if fullName!.isEmpty {
            errorMessage = StringConstants.ENTER_FULL_NAME
        } else if email!.isEmpty {
            errorMessage = StringConstants.ENTER_EMAIL
        } else if !email!.isValidEmail {
            errorMessage = StringConstants.ENTER_VALID_EMAIL
        } else if password!.isEmpty {
            errorMessage = StringConstants.ENTER_PASSWORD
        } else if password!.count < 6 {
            errorMessage = StringConstants.MINIMUM_PASSWORD_REQUIRED
        } else {
            return true
        }
        return false
    }
    
    // MARK: - Functions
    func register(completion: @escaping (_ success: Bool, _ errorMessage: String) -> Void) {
        
        let timestamp = Date().timeIntervalSince1970
        
        let parameter = ParameterRequest()
        parameter.addParameter(key: ParameterRequest.full_name, value: fullName)
        parameter.addParameter(key: ParameterRequest.email, value: email)
        parameter.addParameter(key: ParameterRequest.password, value: password)
        parameter.addParameter(key: ParameterRequest.device_id, value: AppPrefsManager.shared.getDeviceId())
        parameter.addParameter(key: ParameterRequest.device_type, value: DeviceLoginType)
        parameter.addParameter(key: ParameterRequest.device_token, value: AppPrefsManager.shared.getFcmToken())
        parameter.addParameter(key: ParameterRequest.active, value: true)
        parameter.addParameter(key: ParameterRequest.status, value: "online")
        
        var filesAr = [FileParameterRequest]()
        
        if fileData != nil {
            let fileParameter = FileParameterRequest()
            fileParameter.addParameter(key: FileParameterRequest.file_data, value: fileData)
            fileParameter.addParameter(key: FileParameterRequest.param_name, value: "profile_pic")
            fileParameter.addParameter(key: FileParameterRequest.mime_type, value: "image/jpeg")
            fileParameter.addParameter(key: FileParameterRequest.file_name, value: "profile_pic\(timestamp).jpeg")
            filesAr.append(fileParameter)
        }
        
        _ = apiClient.register(parameters: parameter, fileArray: filesAr, completion: { (response, error) in
            
            do {
               
                let statusCode = response?["status"] as? Int ?? 0
                let message = response?["message"] as? String ?? ""
                let data = response?["data"] as? [String : Any] ?? [String : Any]()
                
                if statusCode == ResponseStatus.success {
                    let userJsonData = try JSONSerialization.data(withJSONObject: data, options: .prettyPrinted)
                    self.signUpDataModel = try JSONDecoder().decode(SignUpModel.self, from: userJsonData)
    
                    AppPrefsManager.shared.setUserId(id: self.signUpDataModel!.id!)
                    //AppPrefsManager.shared.setSessionId(id: self.signUpDataModel!.session_id!)
                    //AppPrefsManager.shared.setUserToken(token: self.signUpDataModel!.session_id!)
                    
                    completion(true, message)
                } else {
                    let error = data["error"] as?  [String : Any] ?? [String : Any]()
                    
                    if !error.isEmpty {
                        self.multipleValidation(object: error)
                        completion(false, "Already Register other account in this device")
                    } else {
                        completion(false, message)
                    }
                }
                
            } catch let error {
                DLog("Parser Error = ", error.localizedDescription)
                completion(false, error.localizedDescription)
            }
        })
        
        /*_ = apiClient.register(parameters: parameter, completion: { (response, error) in
            
            guard let response = response else {
                completion(false, "")
                return
            }
            
            let statusCode = response["status"] as? Int ?? 0
            let message = response["message"] as? String ?? ""
            let data = response["data"] as? [String : Any] ?? [String : Any]()
            
            if statusCode == ResponseStatus.success {
                completion(true, message)
            } else {
                let error = data["error"] as?  [String : Any] ?? [String : Any]()
                
                if !error.isEmpty {
                    self.multipleValidation(object: error)
                    completion(false, "")
                } else {
                    completion(false, message)
                }
            }
            
        })*/
    }
    
}

