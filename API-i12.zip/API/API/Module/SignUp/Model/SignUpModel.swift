//
//  SignUpModel.swift


import Foundation

class SignUpModel: Codable {
    var id: Int?
    var full_name: String?
    var email: String?
    var device_type: String?
    var device_token: String?
    var device_id: String?
    var total_coins: Int?
    var status: String?
    var social_type: String?
    var social_id: String?
    var profile_pic: String?
    var active: String?
    var latitude: String?
    var longitude: String?
    var radius: String?
    var remember_token: String?
    var created_at: String?
    var updated_at: String?
    var archive: String?
    var help_description: String?
    var image_path: String?
    var session_id: String?
}
