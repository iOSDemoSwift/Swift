//
//  EmailViewController.swift

import UIKit

protocol EmailViewControllerDelegate: AnyObject {
    func emailAddress(email: String)
}

class EmailViewController: UIViewController {

    //MARK:- Outlets
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var btnDone: UIButton!
    
    //MARK:- Variables
    weak var delegate: EmailViewControllerDelegate?
    
    //MARK:- Life Cycles
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
    }

    //MARK:- Methods
    private func setupUI() {
        txtEmail.addLeftPadding(padding: 20)
        txtEmail.addCornerRadius(10)
        txtEmail.applyBorder(0.5, borderColor: #colorLiteral(red: 0.5926895738, green: 0.5856944323, blue: 0.5961685777, alpha: 1))
        self.btnDone.addCornerRadius(self.btnDone.frame.height / 2)
    }
    
    //MARK:- Actions
    @IBAction func onBtnDone(_ sender: UIButton) {
        if self.txtEmail.text != "" {
            if !self.txtEmail.text!.isValidEmail {
                self.showToastAtBottom(message: StringConstants.ENTER_VALID_EMAIL)
            } else {
                delegate?.emailAddress(email: self.txtEmail.text!)
                self.dismiss(animated: true, completion: nil)
            }
        } else {
            delegate?.emailAddress(email: "")
            self.dismiss(animated: true, completion: nil)
        }
    }
    
}
