//
//  UserSocialDataModel.swift


import Foundation

class UserSocialDataModel {
    
    var id: String        = ""
    var name: String      = ""
    var firstName: String = ""
    var lastName: String  = ""
    var email: String     = ""
    var birthday: String  = ""
    var picture: String   = ""
    var loginType: LoginType = .normal
    
    init() {}
    
    init(withFacebookData data: [String: Any]) {
        id         = data["id"] as? String ?? ""
        name       = data["name"] as? String ?? ""
        firstName  = data["first_name"] as? String ?? ""
        lastName   = data["last_name"] as? String ?? ""
        email      = data["email"] as? String ?? ""
        birthday   = data["birthday"] as? String ?? ""
        
        if let pictureDic = data["picture"] as? [String: Any], let pictureData = pictureDic["data"] as? [String: Any] {
            picture = pictureData["url"] as? String ?? ""
        }
        
        loginType = .facebook
    }
}

