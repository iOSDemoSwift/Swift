//
//  SignInViewController.swift


import UIKit
import FBSDKCoreKit
import FBSDKLoginKit
import Firebase
import SwiftKeychainWrapper

class SignInViewController: BaseViewController {
    
    // MARK: - IBOutlet    
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var btnSignUp: UIButton!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnSignIn: UIButton!
    @IBOutlet weak var btnFacebook: UIButton!
    @IBOutlet weak var viewFacebookContainer: UIView!
    @IBOutlet weak var btnKeepSignedIn: UIButton!
    @IBOutlet weak var viewNavigationContainer: UIView!    
    
    //MARK: - All variables
    private var viewModel = SignInViewModel()
    private var loginViewModel = LoginViewModel()
    private let touchMe = BiometricIDAuth()
    
    lazy var fbEmail = String()
    lazy var email = String()
    lazy var password = String()
    
    var isSignup = false
    
    // MARK: - VC Life Cycles
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
        self.loadDataFromKeyChain()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    // MARK: - Methods
    private func setupUI() {
        navigationController?.isNavigationBarHidden = true
       
        txtEmail.addLeftPadding(padding: 20)
        txtEmail.addCornerRadius(10)
        txtEmail.applyBorder(0.5, borderColor: #colorLiteral(red: 0.5926895738, green: 0.5856944323, blue: 0.5961685777, alpha: 1))
       
        txtPassword.addLeftPadding(padding: 20)
        txtPassword.addCornerRadius(10)
        txtPassword.applyBorder(0.5, borderColor: #colorLiteral(red: 0.5926895738, green: 0.5856944323, blue: 0.5961685777, alpha: 1))
       
        self.btnSignIn.addCornerRadius(self.btnSignIn.frame.size.height / 2)
        btnSignIn.addShadow(color: #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1), opacity: 0.6, offset: CGSize(width: 3.0, height: 3.0), radius: 6)
        self.viewFacebookContainer.applyBorder(0.5, borderColor: .black)
        self.viewFacebookContainer.addCornerRadius(self.viewFacebookContainer.frame.height / 2)
        
        //Gradient
        let height = self.viewNavigationContainer.frame.height
        self.viewNavigationContainer.applyViewGradient(colors: [AppColor.DARK_BLUE, AppColor.DARK_PURPLE], locations: [0.0, 1.0], width: self.view.bounds.width, height: height)
        self.view.layoutIfNeeded()
    }
    
    private func fetchFacebookUserInfo() {
        showLoader()
        GraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, email, picture.type(large)"]).start { (connection, result, error) in
            
            if error == nil {
                DLog("facebook result = ", result)
                let data = result as! [String: Any]
                
                
                if self.fbEmail == "" {
                    guard let _ = data["email"] as? String else {
                        self.hideLoader()
                        self.showToastAtBottom(message: "The email field is required")
                        self.fbEmailContainer()
                        return
                    }
                }
                
                self.loginViewModel.userSocialDataModel = UserSocialDataModel(withFacebookData: data)
                
                if self.fbEmail != "" {
                    self.loginViewModel.userSocialDataModel?.email = self.fbEmail
                }
                
                self.socialLoginApiCall(type: .facebook)
            } else {
                DLog("Error: ", error)
            }
            self.hideLoader()
        }
    }
    
    private func fbEmailContainer() {
        let archiveVC = EmailViewController()
        archiveVC.delegate = self
        archiveVC.modalPresentationStyle = .overFullScreen
        
        self.present(archiveVC, animated: true, completion: nil)
    }
    
    //MARK:- FIRBase
    //Firebase Chat Login and Register
    private func loginFIR(isSocialLogin: Bool) {
        self.showLoader()
        let objUser = viewModel.signInViewModel
        
        if isSocialLogin {
            FirebaseRegister.shared.email = self.loginViewModel.userSocialDataModel?.email ?? ""
            FirebaseRegister.shared.name = self.loginViewModel.userSocialDataModel?.name ?? ""
            FirebaseRegister.shared.imgPath = self.loginViewModel.userSocialDataModel?.picture ?? ""
        } else {
            FirebaseRegister.shared.email = self.txtEmail.text!
            FirebaseRegister.shared.name = objUser?.full_name ?? ""
            FirebaseRegister.shared.imgPath = objUser?.image_path ?? ""
        }
        
        FirebaseRegister.loginFIR(isSocialLogin: isSocialLogin) { (isSuccess) in
            self.hideLoader()
            
            if !isSocialLogin {
                
                switch self.touchMe.biometricType() {
                case .faceID:
                    
                    if let isFaceID = KeychainWrapper.standard.bool(forKey: isFaceIDLogin) {
                        if !isFaceID {
                            self.askPermissionFaceID()
                        } else {
                            self.moveToHome()
                        }
                    } else {
                        self.askPermissionFaceID()
                    }
                    
                    self.askPermissionFaceID()
                default:
                    self.moveToHome()
                    break
                }
                
            } else {
                self.moveToHome()
            }
        }
    }
    
    private func moveToHome() {
        if lastUIScreen == "" && !AppPrefsManager.shared.isUserLoggedIn() {
            AppDelegate.shared.intializeTabBar()
        } else if lastUIScreen == UIScreenName.postLive.rawValue {
            isLastScreen = true
            let nextVC = PostLiveInfoViewController.instantiate(fromAppStoryboard: .Home)
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        
        AppPrefsManager.shared.setIsUserLogin(isLogin: true)
    }
    
    // MARK: - FaceID
    func askPermissionFaceID() {
        let ac = UIAlertController(title: "FaceID", message: "Do you want to login use Face ID?", preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
            //Keychain store
            self.saveDataInKeychain()
        }))
        ac.addAction(UIAlertAction(title: "CANCEL", style: .cancel, handler: { (action) in
           self.moveToHome()
        }))
        
        self.present(ac, animated: true)
    }
    
    func saveDataInKeychain() {
        let objUser = UserLoginModel()
        
        objUser.email = self.txtEmail.text?.trimmed()
        objUser.password = self.txtPassword.text
        
        if KeychainWrapper.standard.set(objUser, forKey: FaceIDLogin) {
            print("save Success")
            let _ = KeychainWrapper.standard.set(true, forKey: isFaceIDLogin)
        }
        
        self.moveToHome()
    }
    
    func loadDataFromKeyChain() {
        if let object: UserLoginModel = KeychainWrapper.standard.object(forKey: FaceIDLogin) as? UserLoginModel {
            email = object.email!
            password = object.password!
            
            self.checkFaceId()
        }
    }
    
    func checkFaceId() {
        if touchMe.canEvaluatePolicy() {
            switch touchMe.biometricType() {
            case .faceID:
                // set Face
                touchMe.authenticateUser() { [weak self] message in
                    if let message = message {
                        // if the completion is not nil show an alert
                        let alertView = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
                        let okAction = UIAlertAction(title: "Darn!", style: .default)
                        alertView.addAction(okAction)
                        self?.present(alertView, animated: true)
                        
                    } else {
                        //self?.dismiss(animated: true)
                        print("Success")
                        self?.loginApiCall()
                    }
                }
            default:
                break
            }
        }
    }
    
    // MARK: - API Call
    private func loginApiCall() {
        view.endEditing(true)
        
        viewModel.email = txtEmail.text == "" ? email : self.txtEmail.text?.trimmed()
        viewModel.password = txtPassword.text == "" ? password : self.txtPassword.text
        
        guard viewModel.validate() else {
            showToastAtBottom(message: viewModel.errorMessage)
            return
        }
        
        AppPrefsManager.shared.setIsUserLogin(isLogin: false)
        
        showLoader()
        viewModel.login { (isSuccess, message) in
            self.hideLoader()
            
            if isSuccess {
                self.loginFIR(isSocialLogin: false)
            } else {
                if let msg = message {
                    self.showToastAtBottom(message: msg)
                }
            }
        }
    }
    
    private func socialLoginApiCall(type: LoginType) {
        view.endEditing(true)
        
        loginViewModel.userSocialDataModel?.loginType = type
        AppPrefsManager.shared.setIsUserLogin(isLogin: false)
        
        showLoader()
        loginViewModel.socialLogin { (isSuccess, message) in
            self.hideLoader()
            if isSuccess {
                self.loginFIR(isSocialLogin: true)
            } else {
                if let msg = message {
                    self.showToastAtBottom(message: msg)
                }
            }
        }
    }
    
    private func goToHomePage()
    {
        let customTabBarController: CustomTabBarController = CustomTabBarController()
        self.navigationController?.pushViewController(customTabBarController, animated: true)
    }
    
    // MARK: - IBActions
    
    @IBAction func onBtnBack(_ sender: UIButton) {
        if isSignup && !AppPrefsManager.shared.isUserLoggedIn() {            
            AppDelegate.shared.intializeTabBar()
        } else {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func onBtnSignUp(_ sender: UIButton) {
        let nextVc = SignUpViewController.instantiate(fromAppStoryboard: .Main)
        navigationController?.pushViewController(nextVc, animated: false)
    }
    
    @IBAction func onBtnSignIn(_ sender: UIButton) {
        loginApiCall()
    }
    
    @IBAction func onBtnFacebook(_ sender: UIButton) {
        let loginManager = LoginManager()
        loginManager.logOut()
        
        loginManager.logIn(permissions: ["public_profile", "email"], from: self) { (loginResult, error) in
            if error != nil {
                Utility.showMessageAlert(title: "Facebook Login Error!", andMessage: error?.localizedDescription ?? "Facebook login failed, please try again later.", withOkButtonTitle: "OK")
            } else if loginResult!.isCancelled {
                
            } else {
                self.fetchFacebookUserInfo()
            }
        }
    }
    
    @IBAction func onBtnKeepSignedIn(_ sender: UIButton) {
        btnKeepSignedIn.isSelected = !btnKeepSignedIn.isSelected
        AppPrefsManager.shared.setIsKeepUserLogin(isLogin: btnKeepSignedIn.isSelected)
    }
    
}

//MARK:- EmailViewControllerDelegate
extension SignInViewController: EmailViewControllerDelegate {
    func emailAddress(email: String) {
        if email != "" {
            self.fbEmail = email
            self.fetchFacebookUserInfo()
        }
    }
}
