//
//  RootContainerViewController.swift


import UIKit

class RootContainerViewController: UIViewController {

    // MARK: - Properties
    var rootViewController: UIViewController?
    var window = Utility.windowMain()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        view.layoutIfNeeded()
        showSplashViewController()
    }
    

    // MARK: - Functions
    // Simulates an API handshake success and transitions to MapViewController
    private func showSplashViewController() {
        showSplashViewControllerNoPing()
        
        delay(time: 1.0) {
            self.goToApplication()
        }
    }
    
    // Does not transition to any other UIViewControllers, SplashViewController only
    private func showSplashViewControllerNoPing() {
        
        if rootViewController is SplashViewController {
            return
        }
        
        rootViewController?.willMove(toParent: nil)
        rootViewController?.removeFromParent()
        rootViewController?.view.removeFromSuperview()
        rootViewController?.didMove(toParent: nil)
        
        let splashViewController = SplashViewController.instantiate(fromAppStoryboard: .Main)
        rootViewController = splashViewController
        //splashViewController.pulsing = true
        
        splashViewController.willMove(toParent: self)
        addChild(splashViewController)
        view.addSubview(splashViewController.view)
        splashViewController.didMove(toParent: self)
    }
    
    /// Displays the MapViewController
    func goToApplication() {
        guard !(rootViewController is UINavigationController) else { return }
        /*
        var nav: UINavigationController!
        nav = AppStoryboard.Main.instance.instantiateViewController(withIdentifier: "LoginNavVc") as? UINavigationController
        
        nav.willMove(toParent: self)
        addChild(nav)
        
        if let rootViewController = self.rootViewController {
            self.rootViewController = nav
            rootViewController.willMove(toParent: nil)
            
            transition(from: rootViewController, to: nav, duration: 0.30, options: [.transitionCrossDissolve, .curveEaseOut], animations: { () -> Void in
                
            }, completion: { _ in
                nav.didMove(toParent: self)
                rootViewController.removeFromParent()
                rootViewController.didMove(toParent: nil)
            })
        } else {
            rootViewController = nav
            view.addSubview(nav.view)
            nav.didMove(toParent: self)
        }*/
        
        AppDelegate.shared.intializeTabBar()
    }
    
    override var prefersStatusBarHidden : Bool {
        switch rootViewController  {
        case is SplashViewController:
            return false
        case is UINavigationController:
            return false
        default:
            return false
        }
    }
    
}
