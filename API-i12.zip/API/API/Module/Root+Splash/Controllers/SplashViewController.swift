//
//  SplashViewController.swift


import UIKit

class SplashViewController: UIViewController {

    @IBOutlet var viewSplashMainContainer: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
