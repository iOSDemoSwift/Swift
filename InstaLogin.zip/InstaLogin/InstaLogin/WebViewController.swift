//
//  WebViewController.swift
//  InstaLogin


import UIKit
import WebKit

let INSTAGRAM_AUTHURL = "https://api.instagram.com/oauth/authorize/"
let INSTAGRAM_USER_INFO = "https://api.instagram.com/v1/users/self/?access_token="
let INSTAGRAM_CLIENT_ID = "a0b79860cca84c308755645cb3d0c77e"
//let INSTAGRAM_CLIENT_SERCRET = "c298547fd1844b42b06a10819fe8f6b9"
let INSTAGRAM_REDIRECT_URI = "http://admin.binomical.com"
//let INSTAGRAM_CLIENT_ID = "443789a49d244101945c6dc05dab6f86"
//let INSTAGRAM_CLIENT_SERCRET = "703ce3aedbc840c9a91432b5634357b6"
//let INSTAGRAM_REDIRECT_URI = "https://www.google.com/"
var INSTAGRAM_ACCESS_TOKEN = "access_token"
let INSTAGRAM_SCOPE = "user_profile"

class WebViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setAPI()
    }
    
    func setAPI() {
        
        let str = "https://api.instagram.com/oauth/authorize?client_id=\(INSTAGRAM_CLIENT_ID),&redirect_uri=\(INSTAGRAM_REDIRECT_URI),&response_type=code,&scope=\(INSTAGRAM_SCOPE)"
        
        let authURL = String(format: "%@?client_id=%@&redirect_uri=%@&response_type=token&scope=%@&DEBUG=True", arguments: [INSTAGRAM_AUTHURL, INSTAGRAM_CLIENT_ID, INSTAGRAM_REDIRECT_URI, INSTAGRAM_SCOPE])
        let urlRequest = URLRequest.init(url: URL.init(string: authURL)!)
        self.webView.uiDelegate = self
        self.webView.navigationDelegate = self
        self.webView.load(urlRequest)
    }
    
    func checkRequestForCallbackURL(request: URLRequest) -> Bool {
        let requestURLString = (request.url?.absoluteString)! as String
        if requestURLString.hasPrefix(INSTAGRAM_REDIRECT_URI) {
            let range: Range<String.Index> = requestURLString.range(of: "#access_token=")!
            handleAuth(authToken: requestURLString.substring(from: range.upperBound))
            return false;
        }
        return true
    }
    
    func handleAuth(authToken: String) {
        INSTAGRAM_ACCESS_TOKEN = authToken
        print("Instagram authentication token ==", authToken)
        getUserInfo(){(data) in
            DispatchQueue.main.async {
//                self.dismiss(animated: true, completion: nil)
                self.navigationController?.popViewController(animated: true)
            }
            
        }
    }
    
    func getUserInfo(completion: @escaping ((_ data: Bool) -> Void)) {
        let url = String(format: "%@%@", arguments: [INSTAGRAM_USER_INFO, INSTAGRAM_ACCESS_TOKEN])
        var request = URLRequest(url: URL(string: url)!)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let session = URLSession.shared
        let task = session.dataTask(with: request, completionHandler: { data, response, error -> Void in
            guard error == nil else {
                completion(false)
                //failure
                return
            }
            // make sure we got data
            guard let responseData = data else {
                completion(false)
                //Error: did not receive data
                return
            }
            do {
                guard let dataResponse = try JSONSerialization.jsonObject(with: responseData, options: [])
                    as? [String: AnyObject] else {
                        completion(false)
                        //Error: did not receive data
                        return
                }
                print(dataResponse)
                
                let data = dataResponse["data"] as? [String: Any] ?? [String : Any]()
                
                do {
        
                    self.getUserFromInstagramUser(data)
//                    let user: User = self.getUserFromInstagramUser(data)
//
//                    if user.socialMediaId != nil && user.socialMediaId != "" {
//                        self.delegate?.getInstaUserData(user)
//                    }
                    
                    completion(true)
                } catch let error as NSError {
                    print(error.localizedDescription)
                    completion(false)
                }
                
                
                // success (dataResponse) dataResponse: contains the Instagram data
            } catch let err {
                print(err.localizedDescription)
                completion(false)
                //failure
            }
        })
        task.resume()
    }
    
    func getUserFromInstagramUser(_ dic: [String: Any])  {
        
        print("id: \(dic["id"]), name: \(dic["full_name"])")
        
//        let user = User()
//        user.socialMediaId = dic["id"] as? String
        //user.firstname = dic["full_name"] as? String
        
//        if let name = dic["full_name"] as? String, !name.isEmpty {
//            let names = name.components(separatedBy: " ")
//            if names.count > 0 {
//                user.lastname = names[0]
//                if names.count > 1 {
//                    user.firstname = names[1]
//                }
//            }
//        }
        
//        user.userName = dic["username"] as? String
//        user.avatarUrl = dic["profile_picture"] as? String
//        user.socialMedia = SocialMediaLogin.INSTAGRAM
        
        if let dicCounts = dic["counts"] as? [String: Any] {
            print(dicCounts)
        }
        
        
    }

}

//MARK:- UIWebViewDelegate
extension WebViewController: WKNavigationDelegate, WKUIDelegate {
    func webView(_ webView: WKWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebView.NavigationType) -> Bool {
        return checkRequestForCallbackURL(request: request)
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping ((WKNavigationActionPolicy) -> Void)) {

        print("webView:\(webView) decidePolicyForNavigationAction:\(navigationAction) decisionHandler:\(decisionHandler)")

        if let url = navigationAction.request.url {
                print(url.absoluteString)
                if url.absoluteString.hasPrefix("https://example.com"){
                    print("SUCCESS")
             }
        }
        
        _ = self.checkRequestForCallbackURL(request: navigationAction.request)

        decisionHandler(.allow)
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        print("Start Request")
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        print("Failed Request")
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("Finished Request")
    }
    
}
