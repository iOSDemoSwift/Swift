//
//  ViewController.swift
//  InstaLogin


import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func onBtnLogin(_ sender: UIButton) {
        
        let objVC = WebViewController()
        objVC.modalPresentationStyle = .overFullScreen
        self.present(objVC, animated: true, completion: nil)
        
    }
    
}

