//
//  Users.swift
//  SocialLogin
//
//  Created by Piyush Chodvadiya on 05/03/20.
//  Copyright © 2020 Asd. All rights reserved.
//

import Foundation

class Users: Codable {
    var id: String
    var name: String
    var first_name: String
    var last_name: String
    var email: String
    var gender: String
    var birthday: String
    var age_range: AgeRange?
    var friends: Friends
    var picture: Picture
    var socialMedia: String?
}

class AgeRange: Codable {
    var min: Int? = 0
    var max: Int? = 0
}

class Friends: Codable {
    var summary: Summary
}

class Summary: Codable {
    var total_count: Int
}

class Picture: Codable {
    var data: PicturUrl
}

class PicturUrl: Codable {
    var url: String
}
