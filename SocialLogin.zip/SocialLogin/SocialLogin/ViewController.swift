//
//  ViewController.swift
//  SocialLogin


import UIKit
import FBSDKLoginKit

class ViewController: UIViewController {

    var arrSocialLoginUsers: Users?
    var swifter: Swifter
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    //MARK:- Actions
    @IBAction func buttonFBAction(_ sender: UIButton) {
        self.fbLogin()
    }
    
    @IBAction func buttonLinkedInAction(_ sender: UIButton) {
        self.linkedLogin()
    }

    //MARK:- Methods
    //MARK:- Facebook
    func fbLogin() {
        let loginManager = LoginManager()
        
        if AccessToken.current != nil {
            LoginManager().logOut()
        }
        
        loginManager.logOut()
        loginManager.logIn(permissions: ["user_birthday", "public_profile", "email", "user_age_range", "user_friends", "user_gender"], from: self) { (loginResult, error) in
            if error != nil {
                print(error!.localizedDescription)
            } else if loginResult!.isCancelled {
                
            } else {
                self.fetchFacebookUserInfo()
            }
        }
    }
    
    private func fetchFacebookUserInfo() {
        GraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, middle_name, last_name, email, gender, age_range, birthday, friends, picture.type(large)"]).start { (connection, result, error) in
            
            if error == nil {
                do {
                    let resultData = result as Any
                    let jsonData = try JSONSerialization.data(withJSONObject: resultData, options: .prettyPrinted)
                    self.arrSocialLoginUsers = try JSONDecoder().decode(Users.self, from: jsonData)
                    
                    self.arrSocialLoginUsers?.socialMedia = SocialMediaLogin.FACEBOOK
                    
                    //print(user.name)
                } catch {
                    print(error.localizedDescription)
                }
            } else {
                print("Not Login")
            }
        }
    }
    
    //MARK:- Linkedin
    private func linkedLogin() {
        var user: Users?
//        SVProgressHUD.show()
        LinkedinLogin.shared.linkedinLogin { (isSuccess, message) in
//            SVProgressHUD.dismiss()
            if isSuccess {
                user = LinkedinLogin.shared.getLinkedinUserProfile()
                
                if user != nil {
                    //Login and go to home
                } else {
                    if(message != "") {
//                        SVProgressHUD.showError(withStatus: message)
                    }
                }
            }
        }
    }
    
    //MARK:- Twitter
    private func twitterLogin() {
        let failureHandler: (Error) -> Void = { error in
            //self.alert(title: "Error", message: error.localizedDescription)
        }
        
        let url = URL(string: TW_CALL_BACK_URL)! // URL(string: "swifter://success")!
        swifter.authorize(withCallback: url, presentingFrom: self, success: { accessToken, response in
            let user: Users?
            
            if let userID = accessToken?.userID, let userName = accessToken?.screenName {
                self.fetchTwitterUserInfo(userTag: UserTag.id(userID))
            }
            
        }, failure: failureHandler)
    }
    
    private func fetchTwitterUserInfo(userTag: UserTag) {
//        SVProgressHUD.show()
        self.swifter.showUser(userTag, includeEntities: false, success: { (json) in
//            SVProgressHUD.dismiss()
            let user: Users? // = APIJSON.toAuthenticateTwiter(responseObject: json.object as AnyObject)
            user!.socialMedia = SocialMediaLogin.TWITTER
            self.getTwitterEmail(userTag: userTag, user: user!)
        }, failure: { (error) in
//            SVProgressHUD.dismiss()
        })
    }
    
    private func getTwitterEmail(userTag: UserTag, user: Users) {
//        SVProgressHUD.show()
        self.swifter.verifyAccountCredentials(includeEntities: true, skipStatus: false, includeEmail: true, success: { (json) in
//            SVProgressHUD.dismiss()
            if let responseObj = json.object {
                user.email = (responseObj["email"]?.string)!
            }
            //go to home page
        }) { (error) in
//            SVProgressHUD.dismiss()
            //self.continueWithRegistration(user: user, logInVia: SocialMediaLogin.TWITTER)
        }
    }
    
}

