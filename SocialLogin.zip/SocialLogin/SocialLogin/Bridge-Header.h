//
//  Bridge-Header.h
//  SocialLogin


#ifndef Bridge_Header_h
#define Bridge_Header_h

#import <LinkedinSwift/LSHeader.h>

#endif /* Bridge_Header_h */
