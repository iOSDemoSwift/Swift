//
//  Constants.swift
//  SocialLogin

import Foundation

//Fb
let FbAppID = ""

//Linkedin
let ClIENT_ID                   = ""
let CLIENT_SECRET               = ""
let LI_CALL_BACK_URL            = "https://admin.binomical.com/app/post-registration-letter" //"https://linkedin_authorization/"
let LI_AUTHORIZATION_END_POINT  = "https://www.linkedin.com/oauth/v2/authorization" // //"https://www.linkedin.com/uas/oauth2/authorization" "https://www.linkedin.com/oauth/v2/authorization"
let LI_ACCESS_TOKEN_END_POINT   = "https://www.linkedin.com/oauth/v2/accessToken" // //"https://www.linkedin.com/uas/oauth2/accessToken" "https://www.linkedin.com/oauth/v2/accessToken"
let LI_STATE = ""

//Scop
let LI_SCOPE_EMAIL_ADDRESS = "r_emailaddress"
let LI_SCOPE_BASIC_PROFILE = "r_basicprofile"
let LI_SCOPE_LITE_PROFILE = "r_liteprofile"

//get profile Linkedin
let LI_BASIC_PROFILE_URL = "https://api.linkedin.com/v2/me?projection=(id,firstName,lastName,profilePicture(displayImage~:playableStreams))"
let LI_EMAIL_ADDRESS_URL = "https://api.linkedin.com/v2/emailAddress?q=members&projection=(elements*(handle~))"

///Linkedin
var liID = ""
var liEmail = ""
var liFirstName = ""
var liLastName = ""
var liProfileUrl = ""

//Twitter
let TW_KEY      = ""
let TW_SECRET   = "" 
let TW_CALL_BACK_URL = "twitterkit-2tzGJBrhvVxJ84AEAFsPfUwBw://success"
