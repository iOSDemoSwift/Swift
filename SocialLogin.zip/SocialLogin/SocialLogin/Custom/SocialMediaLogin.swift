//
//  SocialMediaLogin.swift
//  SocialLogin

import Foundation

class SocialMediaLogin {
    
    static let FACEBOOK     = "facebook"
    static let LINKEDIN     = "linkedin"
    static let TWITTER      = "twitter"
    static let INSTAGRAM    = "instagram"
    
}
