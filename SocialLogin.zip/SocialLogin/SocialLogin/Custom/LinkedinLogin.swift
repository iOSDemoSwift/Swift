//
//  LinkedinLogin.swift
//  SocialLogin

import UIKit

class LinkedinLogin: NSObject {
    
    //MARK:- Variables
    static let shared = LinkedinLogin()
    
    lazy var id = String()
    lazy var fullName = String()
    lazy var email = String()
    
    let linkedinHelper = LinkedinSwiftHelper(configuration: LinkedinSwiftConfiguration(clientId: ClIENT_ID, clientSecret: CLIENT_SECRET, state: LI_STATE, permissions: [LI_SCOPE_LITE_PROFILE, LI_SCOPE_EMAIL_ADDRESS], redirectUrl: LI_CALL_BACK_URL), nativeAppChecker: WebLoginOnly())
    
     //MARK:- Functions
    func linkedinLogin(completion: @escaping (_ success: Bool, _ errorMessage: String) -> Void) {
        linkedinHelper.authorizeSuccess({ [unowned self] (lsToken) -> Void in
            self.getProflie(completion: { (isSuccess, message) in
                  
                    if isSuccess {
                        self.getEmail(completion: { (isSucess, msg) in
                            
                            if isSucess {
                                completion(true, "")
                            } else {
                                completion(false, msg)
                            }
                            
                        })
                    } else {
                        //completion(false, message)
                        completion(true, "")
                    }
                })
            }, error: { [unowned self] (error) -> Void in
                
                completion(false, error.localizedDescription)
            }, cancel: { [unowned self] () -> Void in
                
                completion(false, "User Cancelled!")
        })
    }
    
    func logout() {
        linkedinHelper.logout()
    }
    
    private func getProflie(completion: @escaping (_ success: Bool, _ errorMessage: String) -> Void) {
        //let str = "https://api.linkedin.com/v2/me?projection=(id,firstName,lastName,profilePicture(displayImage~:playableStreams))"
        
        linkedinHelper.requestURL(LI_BASIC_PROFILE_URL, requestType: LinkedinSwiftRequestGet, success: { (response) -> Void in
            
            if response.statusCode == 200 {
                print(response.jsonObject)
                do {
                    let id: String = (response.jsonObject["id"] as? String)!
                    let firstname: [String: Any] = (response.jsonObject["firstName"] as? [String: Any])!
                    let flocalized: [String: Any] = (firstname["localized"] as? [String: Any])!
                    let fName: String = (flocalized["en_US"] as? String)!
                    let lastName: [String: Any] = (response.jsonObject["lastName"] as? [String: Any])!
                    let llocalized: [String: Any] = (lastName["localized"] as? [String: Any])!
                    let lName: String = (llocalized["en_US"] as? String)!
                    
                    if let profilePictureObj = response.jsonObject["profilePicture"] as? [String: Any], let displayImageObj = profilePictureObj["displayImage~"] as? [String: Any], let elements = displayImageObj["elements"] as? [[String: Any]] {
                        
                        if let elementObj = elements.last, let identifiersAr = elementObj["identifiers"] as? [[String: Any]] {
                            if let identifier = identifiersAr.first?["identifier"] as? String {
                                //liProfileUrl = identifier
                            }
                        }
                    }
                    
//                    liID = id
//                    liFirstName = fName
//                    liLastName = lName
                    
                    completion(true, "")
                } catch let error {
                    completion(false, error.localizedDescription)
                }
            }
        }) { [unowned self] (error) -> Void in
            completion(false, error.localizedDescription)
        }
    }
    
    private func getEmail(completion: @escaping (_ success: Bool, _ errorMessage: String) -> Void) {
        //let str = "https://api.linkedin.com/v2/emailAddress?q=members&projection=(elements*(handle~))"
        
        linkedinHelper.requestURL(LI_EMAIL_ADDRESS_URL, requestType: LinkedinSwiftRequestGet, success: { (response) -> Void in
            
            if response.statusCode == 200 {
                print(response.jsonObject)
                do {
                    let elements: [[String: Any]] = (response.jsonObject["elements"] as? [[String: Any]])!
                    //print(elements)
                    let data: [String: Any] = (elements[0] as? [String:Any])!
                    let handle: [String: Any] = (data["handle~"] as? [String:Any])!
                    let email : String = (handle["emailAddress"] as? String)!
                    
//                    liEmail = email
                    
                    completion(true, "")
                } catch let error {
                    completion(false, error.localizedDescription)
                }
            }
            
        }) { [unowned self] (error) -> Void in
           completion(false, error.localizedDescription)
        }
    }
    
    func getLinkedinUserProfile() -> Users? {
        var user: Users?
        
        user?.id = liID
        user?.first_name = liFirstName
        user?.last_name = liLastName
        user?.email = liEmail
        user?.picture.data.url = liProfileUrl
        user?.socialMedia = SocialMediaLogin.LINKEDIN
        
        return user ?? nil
    }

}
