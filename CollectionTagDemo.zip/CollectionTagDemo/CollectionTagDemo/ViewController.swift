//
//  ViewController.swift
//  CollectionTagDemo


import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var viewAllGenre: UIView!
    
    @IBOutlet weak var nlcViewHight: NSLayoutConstraint!
    
    lazy var arrColumnCount = [Int]()
    lazy var arrColumnTags = [[String: Any]]()
    
    let arrTags = [
        ["id": 1, "tag": "one"], ["id": 2, "tag": "two"]
        ,["id": 3, "tag": "three"], ["id": 4, "tag": "four"]
        ,["id": 5, "tag": "five"], ["id": 6, "tag": "six"]
        ,["id": 7, "tag": "seven"], ["id": 8, "tag": "eight"], ["id": 9, "tag": "nine"]
        ,["id": 10, "tag": "ten"]
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        countColumn()
        displayPattern()
    }

    private func displayPattern() {
        
        let startPost: CGFloat = 20, distance: CGFloat = 10
        let height: CGFloat = 45
        
        var xPost: CGFloat = 0, yPost: CGFloat = 0
        
        let totalCount = arrTags.count
        let rCount = Int(round(Double(totalCount / 2)))
        
        let totalHeightOfView: CGFloat = ((CGFloat(rCount) * height) + (CGFloat(rCount) + distance)) + 50
        nlcViewHight.constant = totalHeightOfView
        
        var index = 0
            
        for r in 0..<rCount {
            let col = arrColumnCount[r]
            
            xPost = startPost
            
            for _ in 0..<col {
                let dic = arrTags[index]
                let title = dic["tag"] as! String
                let width: CGFloat = (getWidthForString(withConstrainedHeight: 45, font: UIFont.systemFont(ofSize: 25), str: title) + 50)
                
                let btn = UIButton()
                btn.frame = CGRect(x: xPost, y: yPost, width: width, height: height)
                self.viewAllGenre.addSubview(btn)
                
                btn.titleLabel?.textColor = .white
                btn.backgroundColor = .darkGray
                btn.isSelected = false
                
                btn.setTitle(title, for: .normal)
                btn.tag = dic["id"] as! Int
                
                index += 1
                xPost += (width + distance)
            }
            
            yPost += (distance + height)
        }
    }
    
    private func countColumn() {
        
        let totalCount = arrTags.count
        let rCount = Int(round(Double(totalCount / 2)))
        var tmpCount = totalCount
        
        if rCount >= 4 {
            for r in 0..<rCount {
                if r == 3 {
                    if tmpCount > 2 {
                        tmpCount -= 3
                        arrColumnCount.append(3)
                    } else {
                        arrColumnCount.append(tmpCount)
                        tmpCount = 0
                    }
                } else {
                    tmpCount -= 2
                    
                    tmpCount > 1 ?
                        arrColumnCount.append(2) :
                        arrColumnCount.append(1)
                }
            }
        } else {
            
            for _ in 0..<rCount {
                tmpCount -= 2
                
                tmpCount > 1 ?
                    arrColumnCount.append(2) :
                    arrColumnCount.append(1)
            }
        }
    }
    
}

func getWidthForString(withConstrainedHeight height: CGFloat, font: UIFont, str: String) -> CGFloat {
    let constraintRect = CGSize(width: .greatestFiniteMagnitude, height: height)
    let boundingBox = str.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil)
    
    return ceil(boundingBox.width)
}
