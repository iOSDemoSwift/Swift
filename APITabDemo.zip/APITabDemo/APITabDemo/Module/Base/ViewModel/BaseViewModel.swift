//
//  BaseViewModel.swift


import Foundation
import UIKit

class BaseViewModel {
    
    // MARK: - Variable
    var isApiRunning = false
    var enablePagination = false
    var pageIndex = 0
    var errorMessage = ""
    
    var showAlertClosure: (() -> ())?
    var updateLoadingStatus: (() -> ())?
    var didFinishFetch: (() -> ())?
    
    lazy var apiClient = APIClient()
    
//    lazy var addPost = [AddPostModel]()
    private var alert: UIAlertController?
    
    // MARK: - Functions
    func multipleValidation(object: [String:Any]) {
        var errorMessage = ""
        for key in object.keys {
            if let errorTypes = object[key] as? [String] {
                for errorMsg in errorTypes {
                    let msg = errorMessage + "•"
                    errorMessage = msg + errorMsg + "\n"
                }
            }
        }
        
        Utility.showMessageAlert(title: "Validation", andMessage: errorMessage, withOkButtonTitle: "OK")
    }
    
    func logout(completion: @escaping (_ success: Bool, _ errorMessage: String) -> Void) {
        
      /*  _ = apiClient.logout(completion: { (response, error) in
            
            guard let response = response else {
                completion(false, "")
                return
            }
            
            do {
                let statusCode = response["status"] as? Int ?? 0
                let message = response["message"] as? String ?? ""
                                
                if statusCode == ResponseStatus.success {
                    completion(true, message)
                } else {
                    completion(false, message)
                }
            } catch let error {
                DLog("Parser Error: ", error.localizedDescription)
                completion(false, error.localizedDescription)
            }
        })*/
    }
    
    
    func showAlertForNoInternet() {
        
        Utility.showMessageAlert(title: "Internet!", andMessage: "Please check your internet connection or try again later", withOkButtonTitle: "OK")
        
        /*if alert == nil {
            alert = UIAlertController(title: "Internet!", message: "Please check your internet connection or try again later", preferredStyle: UIAlertController.Style.alert)
            
            alert?.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (_) in
                self.alert = nil
            }))
            
            //self.present(alert!, animated: true, completion: nil)
        }*/
    }
    
}
