//
//  BaseViewController.swift


import UIKit
//import Firebase

class BaseViewController: UIViewController {

    // MARK: - Variable
    private var viewModel = BaseViewModel()
    private var isFromChat = Bool()
    private var alert: UIAlertController?
    
    // MARK: - Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    // MARK: - Methods
    func setupLeftBarBackItem() {
        let backItem = UIBarButtonItem(image: UIImage(named: "ic_back"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(onBackItem(_:)))
        self.navigationItem.leftBarButtonItem = backItem
    }
    
    func setupLeftBarBackItemFromChat(_ isFrom: Bool = false) {
        let backItem = UIBarButtonItem(image: UIImage(named: "ic_back"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(onBackItemFromChat(_:)))
        isFromChat = isFrom
        self.navigationItem.leftBarButtonItem = backItem
    }
    
    func setupLeftBarItem() {
        let backItem = UIBarButtonItem(image: UIImage(named: ""), style: UIBarButtonItem.Style.plain, target: self, action: #selector(onBlanckItem(_:)))
        self.navigationItem.leftBarButtonItem = backItem
    }
    
    func showTabBar()
    {
        guard let customTabBarController = self.tabBarController as? CustomTabBarController else {
            return
        }
        customTabBarController.setTabBarHidden(tabBarHidden: false, vc: self)
    }
    
    func hideTabBar()
    {
        guard let customTabBarController = self.tabBarController as? CustomTabBarController else {
            return
        }
        
        customTabBarController.setTabBarHidden(tabBarHidden: true, vc: self)
    }
    
    func setupRightBarSettingItem() {
        let settingItem = UIBarButtonItem(image: UIImage(named: "ic_setting"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(onSettingItem(_:)))
        self.navigationItem.rightBarButtonItem = settingItem
    }
    
    func setupRightBarRefereshItem() {
        let refereshItem = UIBarButtonItem(image: UIImage(named: "ic_referesh"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(onRefershItem(_:)))
        self.navigationItem.rightBarButtonItem = refereshItem
    }
    
     func share(shareQuestion: String?, shareLocation: String?, shareUrgency: String?, shareDesc: String?, shareCategory: String?, shareImage: UIImage?) {
     
         var objectsToShare = [AnyObject]()
        
         if let shareTextObj = shareQuestion {
            objectsToShare.append(shareTextObj as AnyObject)
         }
        
         if let shareTextObj = shareLocation {
            objectsToShare.append(shareTextObj as AnyObject)
         }
        
         if let shareTextObj = shareUrgency {
            objectsToShare.append(shareTextObj as AnyObject)
         }
        
         if let shareTextObj = shareDesc {
            objectsToShare.append(shareTextObj as AnyObject)
         }
        
         if let shareTextObj = shareCategory {
            objectsToShare.append(shareTextObj as AnyObject)
         }
        
         if let shareImageObj = shareImage {
            objectsToShare.append(shareImageObj)
         }
        
         if shareQuestion != nil || shareImage != nil {
            let activityViewController = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
         
            present(activityViewController, animated: true, completion: nil)
         } else {
            print("There is nothing to share")
         }
     }
    
    func logoutApiCall() {
        showLoader()
        viewModel.logout { (isSuccess, message) in
            self.hideLoader()
            //self.showToastAtBottom(message: message)
            if isSuccess {
//                FirebaseRegister.shared.firebaseLogout()
//                AppDelegate.shared.logOutFromApplication()
            }
        }
    }
    
    func askForLogOut() {
        DispatchQueue.main.async {
            let alertController: UIAlertController = UIAlertController(title: "Logout!" , message: "Are you sure you want to Logout?", preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (_) -> Void in
            }))
            
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (_) -> Void in
                self.logoutApiCall()
            }))
            
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func showAlertForNoInternet() {
        if alert == nil {
            alert = UIAlertController(title: "Internet!", message: "Please check your internet connection or try again later", preferredStyle: UIAlertController.Style.alert)
            
            alert?.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (_) in
                self.alert = nil
            }))
            
            self.present(alert!, animated: true, completion: nil)
        }
    }
    
    // MARK: - Actions
    @objc func onBackItem(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @objc func onBackItemFromChat(_ sender: Any) {
        if isFromChat {
           
            AppDelegate.shared.intializeTabBar()
            selectTabIndex = 1
//            NotificationCenter.default.post(name: SelectReqAndSolTabNotificationName, object: nil)
            
        } else {
            navigationController?.popViewController(animated: true)
        }
    }
    
    
    @objc func onBlanckItem(_ sender: Any) {
        
    }
    
    @objc func onSettingItem(_ sender: Any) {
        
    }
    
    @objc func onRefershItem(_ sender: Any) {
        
    }
    
}
