//
//  SignInModel.swift


import Foundation

class SignInModel: Codable {
    var id: Int?
    var full_name: String?
    var email: String?
    var device_type: String?
    var device_token: String?
    var device_id: String?
    var total_coins: Int?
    var status: String?
    var remember_token: String?
    var created_at: String?
    var updated_at: String?
    var social_type: String?
    var social_id: String?
    var session_id: String?
    var user_id: Int?
    var profile_pic: String?    
    var latitude: String?
    var longitude: String?
    var image_path: String?
}

class UserLoginModel: NSObject, NSCoding  {
    var email: String?
    var password: String?
    
    override init() { }
    
    required init?(coder decoder: NSCoder) {
        if let email = decoder.decodeObject(forKey: "email") as? String {
            self.email = email
        }
        
        if let password = decoder.decodeObject(forKey: "password") as? String {
            self.password = password
        }
    }
    
    func encode(with encoder: NSCoder) {
        encoder.encode(self.email, forKey: "email")
        encoder.encode(self.password, forKey: "password")
    }
}
