//
//  SignInViewModel.swift


import Foundation

class SignInViewModel: BaseViewModel {
    
    // MARK: - Variable
    static let shared = SignInViewModel()
    var signInViewModel: SignInModel?
    
    var email: String?
    var password: String?
    
    // MARK: - Validations
    func validate() -> Bool {
        if email!.isEmpty {
            errorMessage = StringConstants.ENTER_EMAIL
        } else if !email!.isValidEmail {
            errorMessage = StringConstants.ENTER_VALID_EMAIL
        } else if password!.isEmpty {
            errorMessage = StringConstants.ENTER_PASSWORD
        } else if password!.count < 6 {
            errorMessage = StringConstants.MINIMUM_PASSWORD_REQUIRED
        } else {
            return true
        }
        return false
    }
    
    // MARK: - Functions
    func login(completion: @escaping (_ success: Bool, _ errorMessage: String?) -> Void) {
        
        guard ApiManager.isNetworkReachable() else {
            showAlertForNoInternet()
            return
        }
        
        let parameter = ParameterRequest()
        
        parameter.addParameter(key: ParameterRequest.email, value: email)
        parameter.addParameter(key: ParameterRequest.password, value: password)
        parameter.addParameter(key: ParameterRequest.device_type, value: DeviceLoginType)
        parameter.addParameter(key: ParameterRequest.device_id, value: AppPrefsManager.shared.getDeviceId())
        parameter.addParameter(key: ParameterRequest.device_token, value: AppPrefsManager.shared.getFcmToken())
        parameter.addParameter(key: ParameterRequest.type, value: "normal")
        /*
        _ = apiClient.login(parameters: parameter, completion: { (response, error) in
            
            guard let response = response else {
                completion(false, "")
                return
            }
            
            do {
                let statusCode = response["status"] as? Int ?? 0
                let message = response["message"] as? String ?? ""
                let userData = response["data"] as? [String : Any] ?? [String : Any]()
                
                if statusCode == ResponseStatus.success {
                    
                    let userJsonData = try JSONSerialization.data(withJSONObject: userData, options: .prettyPrinted)
                    self.signInViewModel = try JSONDecoder().decode(SignInModel.self, from: userJsonData)
                    
                    AppPrefsManager.shared.setSessionId(id: self.signInViewModel!.session_id!)
                    AppPrefsManager.shared.setUserToken(token: self.signInViewModel!.session_id!)
                    AppPrefsManager.shared.setUserId(id: self.signInViewModel!.id!)                    
                    AppPrefsManager.shared.setUserData(model: self.signInViewModel!)
                    
                    AppDelegate.shared.updateToken()
                    
                    completion(true, message)
                    
                } else {
                    let error = userData["errors"] as?  [String : Any] ?? [String : Any]()
                    
                    if !error.isEmpty {
                        self.multipleValidation(object: error)
                        completion(false, nil)
                    } else {
                        completion(false, message)
                    }
                }
                
            } catch let error {
                DLog("Parser Error = ", error.localizedDescription)
                completion(false, error.localizedDescription)
            }
        })*/
    }
    
    func updateDeviceToken(completion: @escaping (_ success: Bool, _ errorMessage: String?) -> Void) {
        
        guard ApiManager.isNetworkReachable() else {
            showAlertForNoInternet()
            return
        }
        
        let parameter = ParameterRequest()
        
        parameter.addParameter(key: ParameterRequest.device_token, value: AppPrefsManager.shared.getFcmToken())
        /*
        _ = apiClient.updateDeviceToken(parameters: parameter, completion: { (response, error) in
            
            guard let response = response else {
                completion(false, "")
                return
            }
            
            do {
                let statusCode = response["status"] as? Int ?? 0
                let message = response["message"] as? String ?? ""
                
                if statusCode == ResponseStatus.success {
                    completion(true, message)
                } else {
                    completion(false, message)
                }
            } catch let error {
                completion(false, error.localizedDescription)
            }
        })*/
    }
    
}
