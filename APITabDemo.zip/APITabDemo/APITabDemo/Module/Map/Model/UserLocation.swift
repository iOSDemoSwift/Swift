//
//  UserLocation.swift


import Foundation
import MapKit

class Users: Codable {
    var id: Int
    var name: String
    var phone: String
    var address: UserAddress
    var company: UserCompany
}

class UserAddress: Codable {
    var street: String
    var zipcode: String
    var geo: UserLocation
}

class UserLocation: Codable {
    var lat: String
    var lng: String
}

class UserCompany: Codable {
    var name: String?
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class StarbucksAnnotation: NSObject, MKAnnotation {
    
    var coordinate: CLLocationCoordinate2D
    var phone: String!
    var name: String!
    var address: String!
    var image: UIImage!
    
    init(coordinate: CLLocationCoordinate2D) {
        self.coordinate = coordinate
    }
}

class AnnotationView: MKAnnotationView
{
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let hitView = super.hitTest(point, with: event)
        if (hitView != nil)
        {
            self.superview?.bringSubviewToFront(self)
        }
        return hitView
    }
    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool {
        let rect = self.bounds
        var isInside: Bool = rect.contains(point)
        if(!isInside)
        {
            for view in self.subviews
            {
                isInside = view.frame.contains(point)
                if isInside
                {
                    break
                }
            }
        }
        return isInside
    }
}

