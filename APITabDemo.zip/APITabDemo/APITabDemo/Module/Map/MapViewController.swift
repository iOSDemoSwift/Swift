//
//  MapViewController.swift
//  APITabDemo


import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController {
     //MARK:- Outlets
        @IBOutlet weak var mapView: MKMapView!
//        @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
        
        //MARK:- Variables
        var locationManager = CLLocationManager()
        var objMapViewModel = MapViewModel()
        
        //MARK:- Lifecycles
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            self.setupLocation()
            getLocationAPI()
        }
        
        override func viewWillAppear(_ animated: Bool) {
            self.configureServiceLocation()
        }
        
        //MARK:- Methods
        private func configureServiceLocation() {
            if CLLocationManager.authorizationStatus() == .notDetermined {
                locationManager.requestWhenInUseAuthorization()
            }
            
            if CLLocationManager.locationServicesEnabled() {
                locationManager.startUpdatingLocation()
            }
        }
        
        private func setupLocation() {
            mapView.delegate = self
            
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.distanceFilter = kCLDistanceFilterNone
            
            mapView.showsUserLocation = true
            
            self.showActivityIndicator(true)
        }
        
        private func getLocationAPI() {
    //        objMapViewModel.getUserLocation { (isSuccess, message) in
    //            if isSuccess {
    //                self.showAnnotation(locations: self.objMapViewModel.arrUserLocation)
    //            }
    //        }
            
//            objMapViewModel.callAPI { (isSucess, message) in
//                if isSucess {
//                    self.showAnnotation(locations: self.objMapViewModel.arrUserLocation)
//                }
//            }
        }
        
        private func showAnnotation(locations: [Users]) {
            
            let annotations = locations.map { location -> MKAnnotation in
                let annotation = MKPointAnnotation()
                annotation.title = location.company.name
                
                let lat = Utility.stringToDouble(str: location.address.geo.lat)
                let long = Utility.stringToDouble(str: location.address.geo.lng)
                annotation.coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
                
                return annotation
            }
            
            mapView.addAnnotations(annotations)
            
        }
        
        @objc func callPhoneNumber(sender: UIButton)
        {
            let v = sender.superview as! CustomCalloutView
            if let url = URL(string: "telprompt://\(v.starbucksPhone.text!)"), UIApplication.shared.canOpenURL(url)
            {
                UIApplication.shared.openURL(url)
            }
        }
        
        private func showActivityIndicator(_ isShow: Bool) {
//            self.activityIndicator.isHidden = isShow
        }
        
        //MARK:- Action
        
        @IBAction func btnSearchClick(_ sender: UIBarButtonItem) {
            let searchController = UISearchController(searchResultsController: nil)
            searchController.searchBar.layoutIfNeeded()
            searchController.isActive = true
    //        searchController.delegate = self
            searchController.searchBar.delegate = self
            self.present(searchController, animated: true, completion: nil)
        }
        
    }

    extension MapViewController: CLLocationManagerDelegate, MKMapViewDelegate {
        
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
         /*
            if annotation is MKUserLocation {
                return nil
            }
           
            var annotationView = self.mapView.dequeueReusableAnnotationView(withIdentifier: "pin")
            if annotationView == nil {
                annotationView = AnnotationView(annotation: annotation, reuseIdentifier: "pin")
                annotationView?.canShowCallout = false
            } else {
                annotationView?.annotation = annotation
            }
            annotationView?.image = UIImage(named: "pin")
            
            return annotationView
            */
            
            guard let _ = annotation as? MKAnnotation else {
                return nil
            }
            
            var view: MKMarkerAnnotationView
            if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: "pin") as? MKMarkerAnnotationView {
                dequeuedView.annotation = annotation
                view = dequeuedView
            } else {
                view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "pin")
                view.canShowCallout = true
                view.calloutOffset = CGPoint(x: -5, y: 5)
                view.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
            }
            
            return view
            
        }
        
        func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
            // 1
         /*   if view.annotation is MKUserLocation {
                // Don't proceed with custom callout
                return
            }
            
            guard let title = view.annotation!.title! else {
    //            print(title)
                return
            }
            
            // 2
            guard let annotation: [Users] = self.objMapViewModel.arrUserLocation.filter({ $0.company.name == title }), annotation.count > 0 else {
                return
            }
            
            let views = Bundle.main.loadNibNamed("CustomCalloutView", owner: nil, options: nil)
          
            let calloutView = views?[0] as! CustomCalloutView
            calloutView.starbucksName.text = annotation[0].name
            calloutView.starbucksAddress.text = annotation[0].address.street
            calloutView.starbucksPhone.text = annotation[0].phone
            calloutView.starbucksImage.image = UIImage(named: "pin")
            
    //        let button = UIButton(frame: calloutView.starbucksPhone.frame)
    //        button.addTarget(self, action: #selector(MapViewController.callPhoneNumber(sender:)), for: .touchUpInside)
    //        calloutView.addSubview(button)
            
            // 3
            calloutView.center = CGPoint(x: view.bounds.size.width / 2, y: -calloutView.bounds.size.height*0.52)
            view.addSubview(calloutView)
            
            mapView.setCenter((view.annotation?.coordinate)!, animated: true)
     */
        }
        
        func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView) {
            if view.isKind(of: AnnotationView.self) {
                for subview in view.subviews {
                    subview.removeFromSuperview()
                }
            }
        }
        
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            if let location = locations.last {
                
               /* let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
                let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
                
                self.mapView.setRegion(region, animated: true)
                
                let newPin = MKPointAnnotation()
                newPin.coordinate = location.coordinate
                newPin.title = "Current Location"
                self.mapView.addAnnotation(newPin)*/
            }
        }
        
    }

    //MARK:- SearchController Delegate
    extension MapViewController: UISearchBarDelegate {
        func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
           // UIApplication.shared.beginIgnoringInteractionEvents()
            
            self.showActivityIndicator(false)
//            activityIndicator.center = self.view.center
//            activityIndicator.startAnimating()
            
            searchBar.resignFirstResponder()
            dismiss(animated: true, completion: nil)
            
            let searchRequest = MKLocalSearch.Request()
            searchRequest.naturalLanguageQuery = searchBar.text
            
            let activeSearch = MKLocalSearch(request: searchRequest)
            activeSearch.start { (response, error) in
                
                self.showActivityIndicator(true)
                
                if response == nil {
                    print(error?.localizedDescription)
                } else {
                    //remove annotation
                    let annotations = self.mapView.annotations
                    self.mapView.removeAnnotations(annotations)
                    
                    //getting data
                    let lat = response?.boundingRegion.center.latitude
                    let long = response?.boundingRegion.center.longitude
                    
                    //create annotation
                    let annotation = MKPointAnnotation()
                    annotation.title = searchBar.text
                    annotation.coordinate = CLLocationCoordinate2D(latitude: lat!, longitude: long!)
                    self.mapView.addAnnotation(annotation)
                    
                    //zooming in an annotation
                    let coordinate: CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: lat!, longitude: long!)
                    let span = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
                    let region = MKCoordinateRegion(center: coordinate, span: span)
                    self.mapView.setRegion(region, animated: true)
                }
            }
            
            
        }
    }
