//
//  SignUpViewController.swift


import UIKit
//import FBSDKCoreKit
//import FBSDKLoginKit
//import Firebase
//import GoogleSignIn

class SignUpViewController: BaseViewController {
    
    // MARK: - IBOutlet    
    @IBOutlet weak var viwNavigationContainer: UIView!
    @IBOutlet weak var btnSignIn: UIButton!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnSignUp: UIButton!
    @IBOutlet weak var viewFacebookContainer: UIView!
    @IBOutlet weak var btnFacebook: UIButton!
    @IBOutlet weak var btnKeepSignedIn: UIButton!
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var btnPicToImage: UIButton!
    
    // MARK: - Variable
    private var viewModel = SignupViewModel()
//    private var loginViewModel = LoginViewModel()
    var photoData: Data?
    var isLogin = true
    lazy var fbEmail = String()
    
    // MARK: - VC Life Cycles
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.navigationBar.isHidden = true
    }
    
    // MARK: - Methods
    private func setupUI() {
        txtName.addLeftPadding(padding: 20)
        txtName.addCornerRadius(10)
        txtName.applyBorder(0.5, borderColor: #colorLiteral(red: 0.5926895738, green: 0.5856944323, blue: 0.5961685777, alpha: 1))
        
        txtEmail.addLeftPadding(padding: 20)
        txtEmail.addCornerRadius(10)
        txtEmail.applyBorder(0.5, borderColor: #colorLiteral(red: 0.5926895738, green: 0.5856944323, blue: 0.5961685777, alpha: 1))
        
        txtPassword.addLeftPadding(padding: 20)
        txtPassword.addCornerRadius(10)
        txtPassword.applyBorder(0.5, borderColor: #colorLiteral(red: 0.5926895738, green: 0.5856944323, blue: 0.5961685777, alpha: 1))
        
        self.btnSignUp.addCornerRadius(self.btnSignUp.frame.size.height / 2)
        btnSignUp.addShadow(color: #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1), opacity: 0.6, offset: CGSize(width: 3.0, height: 3.0), radius: 6)
        
        self.viewFacebookContainer.applyBorder(0.5, borderColor: .black)
        self.viewFacebookContainer.addCornerRadius(self.viewFacebookContainer.frame.size.height / 2)
        
        imgProfile.addCornerRadius(imgProfile.frame.height / 2)
        
        //Gradient
        let height = self.viwNavigationContainer.frame.height
        self.viwNavigationContainer.applyViewGradient(colors: [AppColor.DARK_BLUE, AppColor.DARK_PURPLE], locations: [0.0, 1.0], width: self.view.bounds.width, height: height)
        self.view.layoutIfNeeded()
    }
    
    //Facebook
    private func fetchFacebookUserInfo() {
        showLoader()
      /*  GraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, email , picture.type(large)"]).start { (connection, result, error) in
            
            if error == nil {
                DLog("facebook result = ", result)
                let data = result as! [String: Any]
                
                
                if self.fbEmail == "" {
                    guard let _ = data["email"] as? String else {
                        self.hideLoader()
                        self.showToastAtBottom(message: "The email field is required")
                        self.fbEmailContainer()
                        return
                    }
                }
                
                self.loginViewModel.userSocialDataModel = UserSocialDataModel(withFacebookData: data)
                
                if self.fbEmail != "" {
                    self.loginViewModel.userSocialDataModel?.email = self.fbEmail
                }
                
                self.socialLoginApiCall(type: .facebook)
            } else {
                DLog("Error: ", error)
            }
            self.hideLoader()
        }*/
    }
    
    private func fbEmailContainer() {
        let archiveVC = EmailViewController()
        archiveVC.delegate = self
        archiveVC.modalPresentationStyle = .overFullScreen
        
        self.present(archiveVC, animated: true, completion: nil)
    }
    
    //MARK:- FIRBase
    //Firebase Chat Login and Register
    private func registerFIR(isSocialLogin: Bool) {
        self.showLoader()
        /*
        if isSocialLogin {
            FirebaseRegister.shared.email = self.loginViewModel.userSocialDataModel?.email ?? ""
            FirebaseRegister.shared.name = self.loginViewModel.userSocialDataModel?.name ?? ""
            FirebaseRegister.shared.imgPath = self.loginViewModel.userSocialDataModel?.picture ?? ""
        } else {
            FirebaseRegister.shared.email = self.txtEmail.text!.trimmed()
            FirebaseRegister.shared.name = self.txtName.text!.trimmed()
            FirebaseRegister.shared.image = self.imgProfile.image ?? #imageLiteral(resourceName: "help")
        }
        
        FirebaseRegister.handleLoginRegisterFIRChat(isSocialLogin: isSocialLogin) { (isSuccess) in
            self.hideLoader()
            
            if lastUIScreen == "" && !AppPrefsManager.shared.isUserLoggedIn() {
                
                if isSocialLogin {
                    AppDelegate.shared.intializeTabBar()
                } else {
                    self.navigationController?.popViewController(animated: true)
                }
                
            } else if lastUIScreen == UIScreenName.postLive.rawValue {
                isLastScreen = true
                let nextVC = PostLiveInfoViewController.instantiate(fromAppStoryboard: .Home)
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
            
            AppPrefsManager.shared.setIsUserLogin(isLogin: true)
        }*/
    }
    
    // MARK: - API Call
    private func registerApiCall() {
        view.endEditing(true)
        
        viewModel.fullName = txtName.text?.trimmed()
        viewModel.email = txtEmail.text?.trimmed()
        viewModel.password = txtPassword.text
        viewModel.fileData = photoData ?? nil
        
        guard viewModel.validate() else {
            self.showToastAtBottom(message: viewModel.errorMessage)
            return
        }
        
        showLoader()
        viewModel.register { (isSuccess, message) in
            self.hideLoader()
            if isSuccess {
                self.registerFIR(isSocialLogin: false)
                self.showToastAtBottom(message: message)
                //self.navigationController?.popViewController(animated: true)
            } else {
                self.showToastAtBottom(message: message)
            }
        }
    }
    
    private func socialLoginApiCall(type: LoginType) {
        view.endEditing(true)
        
//        loginViewModel.userSocialDataModel?.loginType = type
        AppPrefsManager.shared.setIsUserLogin(isLogin: false)
        
        showLoader()
      /*  loginViewModel.socialLogin { (isSuccess, message) in
            self.hideLoader()
            if isSuccess {
                self.registerFIR(isSocialLogin: true)
            } else {
                if let msg = message {
                    self.showToastAtBottom(message: msg)
                }
            }
        }*/
    }
    
    // MARK: - IBActions
    
    @IBAction func onBtnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onBtnSignIn(_ sender: UIButton) {
        if isLogin {
            navigationController?.popViewController(animated: false)
        } else {
            /*let rootVc = SignInViewController.instantiate(fromAppStoryboard: .Main)
            rootVc.isSignup = true
            let navVc = UINavigationController(rootViewController: rootVc)
            AppDelegate.shared.window?.rootViewController = navVc*/
            
            let nextVc = SignInViewController.instantiate(fromAppStoryboard: .Main)
            nextVc.isSignup = true
            navigationController?.pushViewController(nextVc, animated: true)
        }
    }
    
    @IBAction func onBtnSignUp(_ sender: UIButton) {
        registerApiCall()
    }
    
    
    @IBAction func onBtnPicToImage(_ sender: UIButton) {
        selectImage()
    }
    
    @IBAction func onBtnGoogle(_ sender: UIButton) {
        DispatchQueue.main.async {
//            GIDSignIn.sharedInstance().signOut()
//            GIDSignIn.sharedInstance().signIn()
        }
    }
    
    @IBAction func onBtnFacebook(_ sender: UIButton) {
       /* let loginManager = LoginManager()
        loginManager.logOut()
        
        loginManager.logIn(permissions: ["public_profile", "email"], from: self) { (loginResult, error) in
            if error != nil {
                Utility.showMessageAlert(title: "Facebook Login Error!", andMessage: error?.localizedDescription ?? "Facebook login failed, please try again later.", withOkButtonTitle: "OK")
            } else if loginResult!.isCancelled {
                
            } else {
                self.fetchFacebookUserInfo()
            }
        }*/
    }
    
    @IBAction func onBtnKeepSignedIn(_ sender: UIButton) {
        btnKeepSignedIn.isSelected = !btnKeepSignedIn.isSelected
        AppPrefsManager.shared.setIsKeepUserLogin(isLogin: btnKeepSignedIn.isSelected)
    }
    
}

// MARK: - UIImagePickerControllerDelegate and Take a Photo or Choose from Gallery Methods
extension SignUpViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage
        
        self.imgProfile.image = image
        //lbladdPhoto.isHidden = true
        
        photoData = image?.jpegData(compressionQuality: 0.5)
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    //Photo selection methods
    @objc func selectImage() {
        view.endEditing(true)
        
        var alertController = UIAlertController()
        
        alertController.popoverPresentationController?.sourceView = imgProfile
        alertController.popoverPresentationController?.sourceRect = imgProfile.bounds
        alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        alertController.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action) -> Void in
            DispatchQueue.main.async {
                self.loadCameraView()
            }
        }))
        
        alertController.addAction(UIAlertAction(title: "Choose existing", style: .default, handler: { (action) -> Void in
            DispatchQueue.main.async {
                self.loadPhotoGalleryView()
            }
        }))
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    func loadCameraView() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            let imagePickerController = UIImagePickerController()
//            imagePickerController.navigationBar.tintColor =  #colorLiteral(red: 0.2352941176, green: 0.5098039216, blue: 0.6666666667, alpha: 1)
            imagePickerController.sourceType = .camera
            //imagePickerController.mediaTypes = [kUTTypeImage as String]
            imagePickerController.allowsEditing = true
            imagePickerController.delegate = self
            imagePickerController.showsCameraControls = true
            present(imagePickerController, animated: true, completion: nil)
        } else {
            Utility.showMessageAlert(title: "Error", andMessage: "Camera option does not available with this device.", withOkButtonTitle: "OK")
        }
    }
    
    func loadPhotoGalleryView() {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
            let imagePickerController = UIImagePickerController()
            
            imagePickerController.sourceType = .photoLibrary
            //imagePickerController.mediaTypes = [kUTTypeImage as String]
            imagePickerController.allowsEditing = true
            imagePickerController.delegate = self
            
            
            present(imagePickerController, animated: true, completion: nil)
        } else {
            Utility.showMessageAlert(title: "Error", andMessage: "Photo library does not avaialable on this device.", withOkButtonTitle: "OK")
        }
    }
}

//MARK:- EmailViewControllerDelegate
extension SignUpViewController: EmailViewControllerDelegate {
    func emailAddress(email: String) {
        if email != "" {
            self.fbEmail = email
            self.fetchFacebookUserInfo()
        }
    }
}

/*
// MARK: - GIDSignInDelegate
extension LoginViewController: GIDSignInDelegate {
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if let error = error {
            DLog("didSignInFor Error: ", error)
            
            Utility.showMessageAlert(title: "Google Login Error!", andMessage: error.localizedDescription, withOkButtonTitle: "OK")
        } else {
            DLog("didSignInFor user: ", user)
            
            socialViewModel.socialModel = SocialLoginModel(withGoogleData: user)
            socialLoginApiCall(type: .google)
        }
    }
    
    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!, withError error: Error!) {
        DLog("didDisconnectWith Error: ", error)
    }
    
}

// MARK: - GIDSignInUIDelegate
extension LoginViewController: GIDSignInUIDelegate {
    
    func sign(_ signIn: GIDSignIn!, present viewController: UIViewController!) {
        self.present(viewController, animated: true, completion: nil)
    }
    
    func sign(_ signIn: GIDSignIn!, dismiss viewController: UIViewController!) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
*/
