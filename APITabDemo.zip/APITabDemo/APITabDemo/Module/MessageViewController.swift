//
//  MessageViewController.swift
//  APITabDemo


import UIKit

class MessageViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
   
    override func viewWillAppear(_ animated: Bool) {
           self.showTabBar()
       }
}
