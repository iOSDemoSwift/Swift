//
//  CustomTabBarController.swift


import UIKit

class CustomTabBarController: UITabBarController {
    
    // MARK: - Properties
    private var customTabBarView: CustomTabBar!
    private var forceHideTabBar = false
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        customTabBarView = (Bundle.main.loadNibNamed("CustomTabBar", owner: nil, options: nil)!.first as! CustomTabBar)
        customTabBarView.delegate = self
        
        var tabBarHeight = CGFloat()
        
        if DeviceType.IS_IPHONE_X || DeviceType.IS_IPHONE_X_MAX {
            tabBarHeight = 84.0
        } else {
            tabBarHeight = tabBar.frame.size.height
        }
        
        customTabBarView.frame = CGRect(x: 0.0, y: view.frame.size.height - tabBar.frame.size.height, width: view.frame.size.width, height: tabBarHeight)
        view.addSubview(customTabBarView)
        
        customTabBarView.translatesAutoresizingMaskIntoConstraints = false
        
        let heightConstraint = NSLayoutConstraint(item: customTabBarView!, attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: tabBarHeight)
        customTabBarView.addConstraints([heightConstraint])
        
        self.view.addConstraint(NSLayoutConstraint(item: customTabBarView!, attribute: .left, relatedBy: .equal, toItem: self.view, attribute: .left, multiplier: 1, constant: 0))
        
        self.view.addConstraint(NSLayoutConstraint(item: customTabBarView!, attribute: .bottom, relatedBy: .equal, toItem:self.view, attribute: .bottom, multiplier: 1, constant: 0))
        
        self.view.addConstraint(NSLayoutConstraint(item: customTabBarView!, attribute: .right, relatedBy: .equal, toItem: self.view , attribute: .right, multiplier: 1, constant:0))
        
        self.view.layoutIfNeeded()
        
        if forceHideTabBar {
            self.tabBar.isHidden = true
            self.customTabBarView.isHidden = true
        }
        
        setupViewControllers()
    }
    
    private func setupViewControllers()
    {
        var viewControllers = [AnyObject]()
        
        let homeStoryboard = UIStoryboard(name: "Main", bundle: nil)
//        let messagesStoryboard = UIStoryboard(name: "Message", bundle: nil)
//        let requestsStoryboard = UIStoryboard(name: "Requests", bundle: nil)
//        let AccountStoryboard = UIStoryboard(name: "AccountSettings", bundle: nil)
        
        let navController1: UINavigationController = homeStoryboard.instantiateViewController(withIdentifier: "HomeNavVc") as! UINavigationController
        
        let navController2: UINavigationController = homeStoryboard.instantiateViewController(withIdentifier: "MessageNavVc") as! UINavigationController

        let navController4: UINavigationController = homeStoryboard.instantiateViewController(withIdentifier: "HomeNavVc") as! UINavigationController

        let navController5: UINavigationController = homeStoryboard.instantiateViewController(withIdentifier: "MessageNavVc") as! UINavigationController
        
        
        viewControllers = [navController1, navController2, navController4, navController5]
        
        self.viewControllers = viewControllers as? [UIViewController];
        
        self.tabSelecteAtIndex(tabIndex: 0)
    }
    
    func setTabBarHidden(tabBarHidden: Bool, vc: UIViewController?) {
        if tabBarHidden {
            self.tabBar.isHidden = true
            self.customTabBarView.isHidden = tabBarHidden
            
            vc?.edgesForExtendedLayout = UIRectEdge.bottom
        } else {
            if !forceHideTabBar {
                self.tabBar.isHidden = true
                self.customTabBarView.isHidden = tabBarHidden
                
                vc?.edgesForExtendedLayout = UIRectEdge.top
            }
        }
    }
}

// MARK: - CustomTabBarViewDelegate
extension CustomTabBarController: CustomTabBarViewDelegate {
    func tabSelecteAtIndex(tabIndex: Int) {
        let selectedVC =  self.viewControllers![tabIndex]
        
        if tabIndex != 0 {
            if !AppPrefsManager.shared.isUserLoggedIn() {
                //AppPrefsManager.shared.setLoginSignUp()
//                self.setLoginSignUp() //AppExtension.swift
                return
            }
        }
        
        selectedIndex = tabIndex
        
        if self.selectedViewController == selectedVC {
            let navVc = self.selectedViewController as! UINavigationController
            navVc.popToRootViewController(animated: false)
        }
        
        super.selectedViewController = selectedViewController
    }
}
