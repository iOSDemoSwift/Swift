//
//  CustomTabBar.swift


import UIKit

protocol CustomTabBarViewDelegate: AnyObject {
    func tabSelecteAtIndex(tabIndex: Int)
}

class CustomTabBar: UIView {
    
    // MARK: - IBOutlets
    @IBOutlet private var btnTabs: [UIButton] = []
    @IBOutlet weak var viewPlusContainer: UIView!
    
    var normalColor = #colorLiteral(red: 0.3176470697, green: 0.07450980693, blue: 0.02745098062, alpha: 1)
    var selectedColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    private var lastIndex = 0
    weak var delegate: CustomTabBarViewDelegate?
    
    // MARK: -
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        initializeSetup()
        
        NotificationCenter.default.addObserver(self, selector: #selector(defaultTabSelect), name: SelectHomeTabNotificationName, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(selecteNextVC), name: SelectReqAndSolTabNotificationName, object: nil)
    }
    
    // MARK: - Methods
    private func initializeSetup() {
        viewPlusContainer.addCornerRadius(10)
        viewPlusContainer.addShadow(color: #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1), opacity: 0.6, offset: CGSize(width: 3.0, height: 3.0), radius: 6)
        //btnExplore.centerVertically(withPadding: 7)
        
        for btn in btnTabs {
            
            if DeviceType.IS_IPHONE_5 || DeviceType.IS_IPHONE_4_OR_LESS {
                btn.titleLabel?.font = UIFont(name: btn.titleLabel!.font.familyName, size: 10.0)
            }
            
            //btn.centerVerticallyWithPadding(padding: 5.0)            
            
            if btn.tag == 0 {
                btn.isSelected = true
            }
            
            btn.setTitleColor(normalColor, for: .normal)
            btn.setTitleColor(selectedColor, for: .selected)
        }
    }
    
    @objc private func defaultTabSelect() {
        for btn in btnTabs {
            if btn.tag == 0 {
                btn.isSelected = true
            } else {
                btn.isSelected = false
            }
        }
    }
    
    @objc private func selecteNextVC() {
        selectTabAt(index: selectTabIndex)
    }
    
    private func selectTabAt(index: Int) {
        lastIndex = index
        
        for btn in btnTabs {
            if btn.tag == index {
                btn.isSelected = true
            } else {
                btn.isSelected = false
            }
        }
        
        delegate?.tabSelecteAtIndex(tabIndex: lastIndex)
    }
    
    // MARK: - IBActions
    @IBAction private func onBtnTabs(_ sender: UIButton) {
        lastIndex = sender.tag
        
        selectTabAt(index: lastIndex)
    }
    
    @IBAction func onBtnAddPost(_ sender: UIButton) {
        if AppPrefsManager.shared.isUserLoggedIn() {
//            let rootVc = window?.rootViewController as! UINavigationController
//            let nextVc = AddPostViewController.instantiate(fromAppStoryboard: .AddPost)
//            let nav = UINavigationController(rootViewController: nextVc)
            
//            rootVc.present(nav, animated: true, completion: nil)
        } else {
//            let rootVc = window?.rootViewController as! UINavigationController
//            let nextVc = SignUpAndLogInViewController.instantiate(fromAppStoryboard: .Main)
//            let nav = UINavigationController(rootViewController: nextVc)
//
//            rootVc.present(nav, animated: true, completion: nil)
        }
    }
    
    
}
