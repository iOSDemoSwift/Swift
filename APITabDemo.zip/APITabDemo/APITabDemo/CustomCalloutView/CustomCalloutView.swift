//
//  CustomCalloutView.swift

import UIKit
import MapKit

class CustomCalloutView: UIView {

    @IBOutlet var starbucksImage: UIImageView!
    @IBOutlet var starbucksName: UILabel!
    @IBOutlet var starbucksAddress: UILabel!
    @IBOutlet var starbucksPhone: UILabel!
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
