//
//  UIButton+Extension.swift


import Foundation
import UIKit

extension UIButton {
    
    func setBackgroundColor(_ color: UIColor?, for state: UIControl.State) {
        self.setBackgroundImage(color?.image(), for: state)
    }
    
    func makeImageLeftAligned(image: UIImage, leftMargin: CGFloat) {
        let margin = leftMargin - image.size.width / 2
        let titleRect = self.titleRect(forContentRect: self.bounds)
        let titleOffset = (bounds.width - titleRect.width - image.size.width) / 2 - margin / 2        
        
        contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.left
        imageEdgeInsets = UIEdgeInsets(top: 0, left: margin, bottom: 0, right: 0)
        titleEdgeInsets = UIEdgeInsets(top: 0, left: titleOffset, bottom: 0, right: 0)
    }
    
    func centerVerticallyWithPadding(padding: CGFloat) {
        let imageSize: CGSize = (self.imageView?.frame.size)!
        let titleString: NSString = ""
        let titleSize: CGSize = titleString.size(withAttributes: [NSAttributedString.Key.font: (self.titleLabel?.font)!])
        
        let totalHeight: CGFloat = imageSize.height + titleSize.height + padding
        
        self.imageEdgeInsets = UIEdgeInsets(top: -(totalHeight - imageSize.height), left: 0.0, bottom: 0.0, right: -titleSize.width)
        
        self.titleEdgeInsets = UIEdgeInsets(top: 0.0, left: -imageSize.width, bottom: -(totalHeight - titleSize.height), right: 0.0)
    }
    
    func centerVertically() {
        let kDefaultPadding: CGFloat  = 6.0;
        self.centerVerticallyWithPadding(padding: kDefaultPadding);
    }
    
    func setBackGroundColorGradient(_ colors: [UIColor]) {
        let image = UIImage.gradientImageWith(size: CGSize(width: self.frame.width, height: self.frame.height), colors: colors)
        self.clipsToBounds = true
        self.setBackgroundImage(image, for: .normal)
    }
    
    func setBackGroundColorGradient(_ colors: [UIColor], for state: UIControl.State) {
        let image = UIImage.gradientImageWith(size: CGSize(width: self.frame.width, height: self.frame.height), colors: colors)
        self.clipsToBounds = true
        self.setBackgroundImage(image, for: state)
    }
    
    func underline() {
        guard let text = self.titleLabel?.text else { return }
        
        let attributedString = NSMutableAttributedString(string: text)
        attributedString.addAttribute(NSAttributedString.Key.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: NSRange(location: 0, length: text.count))
        
        self.setAttributedTitle(attributedString, for: .normal)
    }
}
