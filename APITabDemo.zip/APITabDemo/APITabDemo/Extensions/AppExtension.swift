//
//  AppExtension.swift


import Foundation
import UIKit
import MBProgressHUD
import Toast_Swift

//MARK:- UIViewController
extension UIViewController {
    func showLoader() {
        DispatchQueue.main.async {
            _ = MBProgressHUD.showAdded(to: Utility.windowMain()!, animated: true)
        }
    }
    
    func hideLoader() {
        DispatchQueue.main.async {
            MBProgressHUD.hide(for: Utility.windowMain()!, animated: true)
        }
    }
    
    func showToastAtBottoms(message: String) {
        self.view.showToastAtBottom(message: message)
    }
    
    func showToastAtBottom(message: String) {
        Utility.windowMain()!.showToastAtBottom(message: message)
    }
    
    func showToastAtTop(message: String) {
        self.view.showToastAtTop(message: message)
    }
}

//MARK:- UIView
extension UIView {
//    func showToastAtBottom(message: String) {
//        guard !message.isEmpty else {
//            return
//        }
//
//        var style = ToastStyle()
//
//        style.messageColor = .white
//        style.backgroundColor = .black
//
//        self.makeToast(message, duration: 4.0, position: .bottom, style: style)
//    }

    public func showToastAtBottom(message: String) {
        var style = ToastStyle()
        style.messageColor = .white
        style.backgroundColor = .black
        self.makeToast(message, duration: 3.0, position: .bottom, style: style)
    }
    
    func showToastAtTop(message: String) {
        guard !message.isEmpty else {
            return
        }
        
        var style = ToastStyle()
        
        style.messageColor = .white
        style.backgroundColor = .black
        
        self.makeToast(message, duration: 4.0, position: .top, style: style)
    }
}

// MARK: - UITableView
extension UITableView {
    
    func scrollToBottom(){
        
        DispatchQueue.main.async {
            let indexPath = IndexPath(
                row: self.numberOfRows(inSection:  self.numberOfSections - 1) - 1,
                section: self.numberOfSections - 1)
            self.scrollToRow(at: indexPath, at: .bottom, animated: true)
        }
    }
    
    func scrollToTop() {
        
        DispatchQueue.main.async {
            let indexPath = IndexPath(row: 0, section: 0)
            self.scrollToRow(at: indexPath, at: .top, animated: false)
        }
    }
}
