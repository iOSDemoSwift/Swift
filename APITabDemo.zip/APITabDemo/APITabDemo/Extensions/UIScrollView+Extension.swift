//
//  UIScrollView+Extension.swift


import Foundation
import UIKit

extension UIScrollView {
    public func isNearBottomEdge(edgeOffset: CGFloat = 20) -> Bool {
        return self.contentOffset.y + self.frame.size.height + edgeOffset > self.contentSize.height
    }
}
