//
//  UILabel+Extension.swift


import UIKit

extension UILabel {

    public func setUnderLine() {
        guard let text = self.text else { return }
        let textRange = NSRange(location: 0, length: text.count) //NSMakeRange(0, text.count)
        let attributedString = NSMutableAttributedString(string: text)
        attributedString.addAttribute(.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: textRange)
        self.attributedText = attributedString
    }

}
