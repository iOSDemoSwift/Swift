//
//  UINavigationController+Extension.swift


import Foundation
import UIKit

extension UINavigationController {
    func applyDarkNavigationBar() {
        self.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor :#colorLiteral(red: 0.2941176471, green: 0.2941176471, blue: 0.2941176471, alpha: 1), NSAttributedString.Key.font : UIFont(name: FontName.rubikBold.rawValue, size: 15.0)!]
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.tintColor = #colorLiteral(red: 0.2941176471, green: 0.2941176471, blue: 0.2941176471, alpha: 1)
        self.navigationBar.isTranslucent = false
        UIApplication.shared.statusBarStyle = .default
    }
    
    func applyLightNavigationBar() {
        self.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor :#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0) , NSAttributedString.Key.font : UIFont(name: FontName.rubikBold.rawValue, size: 15.0)!]
        self.navigationBar.tintColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        self.navigationBar.applyNavigationGradient(colors: [AppColor.DARK_PURPLE, AppColor.LIGHT_ORANGE])
        self.navigationBar.isTranslucent = false
        UIApplication.shared.statusBarStyle = .lightContent
    }
    
    func applyClearNavigationBar() {
        self.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor :#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0) , NSAttributedString.Key.font : UIFont(name: FontName.rubikBold.rawValue, size: 15.0)!]
        self.navigationBar.tintColor = UIColor.white
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationBar.backgroundColor = UIColor.clear
        UIApplication.shared.statusBarStyle = .default
    }
}

