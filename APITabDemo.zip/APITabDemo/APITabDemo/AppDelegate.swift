//
//  AppDelegate.swift
//  APITabDemo


import UIKit
//import FBSDKLoginKit
//import GoogleSignIn

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        intializeTabBar()
        //        //Firebase Notification
        //        setupFirebase()
        //        registerForRemoteNotifications(application: application)
        //        UIApplication.shared.applicationIconBadgeNumber = 0
                
        //        GIDSignIn.sharedInstance()?.clientID = GoogleSignIn_CLIENT_ID
        
        return true
    }

    // MARK: UISceneSession Lifecycle

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.

            return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
        
    }

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    func intializeTabBar() {
        self.window = UIWindow(frame: UIScreen.main.bounds)

        let customTabBarController: CustomTabBarController = CustomTabBarController()

        let navVC = UINavigationController(rootViewController: customTabBarController)
        self.window?.backgroundColor = UIColor.white
        self.window?.rootViewController = navVC
        self.window?.makeKeyAndVisible()
    }
    
     //facebook
//        func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
//            var fbFlag = false
//            fbFlag = ApplicationDelegate.shared.application(application, open: url, sourceApplication: sourceApplication, annotation: annotation)
//            return fbFlag
//        }
        
    //    func setupApplicationUIAppearance() {
    //        IQKeyboardManager.shared.enable = true
    //
    //        UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor : #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), NSAttributedString.Key.font : UIFont(name: "Avenir-Heavy", size: 20.0)!]
    //
    //        UINavigationBar.appearance().tintColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    //        UINavigationBar.appearance().barTintColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
    //        UINavigationBar.appearance().isTranslucent = false
    //    }

    //    private func getDeviceId() {
    //        if AppPrefsManager.shared.isFirstTimeAppRunning() {
    //            let deviceId = UUID().uuidString
    //            AppPrefsManager.shared.setDeviceId(id: deviceId)
    //            AppPrefsManager.shared.setIsFirstTimeAppRunning(run: false)
    //        }
    //    }

        class var shared: AppDelegate {
            return UIApplication.shared.delegate as! AppDelegate
        }
        
    //    //MARK: - setupFirebase Notification
    //    private func setupFirebase() {
    //        FirebaseApp.configure()
    //        Database.database().isPersistenceEnabled = true
    //        Messaging.messaging().delegate = self
    //    }
    //
    //    func registerForRemoteNotifications(application: UIApplication) {
    //        UNUserNotificationCenter.current().delegate = self
    //
    //        let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
    //        UNUserNotificationCenter.current().requestAuthorization(
    //            options: authOptions,
    //            completionHandler: {_, _ in })
    //        application.registerForRemoteNotifications()
    //    }
    //
    //    func handlePushNotification(pushInfo: [String: Any]) {
    //
    //        var dic = [String: Any]()
    //
    //        if pushInfo["push_type"] as? String == "Message" {
    //            let uid = pushInfo["uid"] as? String
    //            if let jsonString = pushInfo["dicUser"] {
    //                dic = Utility.convertToDictionary(text: jsonString as! String)!
    //            }
    //
    //            FirebaseRegister.shared.fetchUsers { (isSuccess, users) in
    //                let user = users.filter {$0.uid == uid}
    //
    //                if isSuccess, user.count > 0 {
    //                    let nextVc = MessagesViewController.instantiate(fromAppStoryboard: .Message)
    //                    nextVc.user = user[0]
    //                    nextVc.isFrom = true
    //                    nextVc.dicNotification = dic
    //                    let navVC = UINavigationController(rootViewController: nextVc)
    //                    AppDelegate.shared.window?.rootViewController = navVC
    //                }
    //            }
    //        } else {
    //            //Home
    //        }
    //    }
    //
    //    //MARK: - Notification Lifecycles
    //    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
    //        DLog("didRegisterForRemoteNotificationsWithDeviceToken")
    //        Messaging.messaging().apnsToken = deviceToken
    //
    //        InstanceID.instanceID().instanceID { (result, error) in
    //            if let error = error {
    //                print("Error fetching remote instance ID: \(error)")
    //            } else if let result = result {
    //                print("Remote instance ID token: \(result.token)")
    //                AppPrefsManager.shared.setFcmToken(token: result.token)
    //            }
    //        }
    //    }
    //
    //    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
    //        DLog("didFailToRegisterForRemoteNotificationsWithError error = ", error)
    //    }

    }

    ////MARK: - UNUserNotificationCenterDelegate
    //extension AppDelegate: UNUserNotificationCenterDelegate {
    //    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
    //        DLog("userNotificationCenter willPresent notification = ", notification.request.content.userInfo)
    //        //handlePushNotification(pushInfo: notification.request.content.userInfo as! [String : Any])
    //        completionHandler([.alert, .sound, .badge])
    //    }
    //    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
    //        DLog("userNotificationCenter didReceive notification = ", response.notification.request.content.userInfo)
    //        handlePushNotification(pushInfo: response.notification.request.content.userInfo as! [String : Any])
    //        completionHandler()
    //    }
    //}
    //
    ////MARK: - MessagingDelegate
    //extension AppDelegate: MessagingDelegate {
    //    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String) {
    //        DLog("didReceiveRegistrationToken = ", fcmToken)
    //        AppPrefsManager.shared.setFcmToken(token: fcmToken)
    //        self.updateFirestorePushTokenIfNeeded(token: fcmToken)
    //    }
    //}
    //
    ////MARK: - Online/Offline Status
    //extension AppDelegate
    //{
    //    func setupUserStatusListener() {
    //        let user_id: String =  AppPrefsManager.shared.getFireBaseUId()
    //        if user_id.count > 0 {
    //            let ref = Database.database().reference().child("users").child(user_id)
    //            ref.updateChildValues(["is_online": true])
    //            ref.onDisconnectUpdateChildValues(["is_online": false])
    //        }
    //    }
    //
    //    func goOnline() {
    //        let user_id: String = AppPrefsManager.shared.getFireBaseUId()
    //        if user_id.count > 0 {
    //            Database.database().reference().child("users").child(user_id).updateChildValues(["is_online": true])
    //        }
    //    }
    //
    //    func goOffline() {
    //        let user_id: String = AppPrefsManager.shared.getFireBaseUId()
    //        if user_id.count > 0 {
    //            Database.database().reference().child("users").child(user_id).updateChildValues(["is_online": false])
    //        }
    //    }
    //
    //    func updateFirestorePushTokenIfNeeded(token: String) {
    //        let user_id: String = AppPrefsManager.shared.getFireBaseUId()
    //        if user_id.count > 0 {
    //            let usersRef = Database.database().reference().child("users").child(user_id)
    //            usersRef.updateChildValues(["fcmToken": token])
    //        }
    //    }
    //}

