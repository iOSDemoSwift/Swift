//
//  AppPrefsManager.swift

import UIKit
import CoreLocation

struct AppPrefsKey {
    static let fcmToken                 = "FCM_TOKEN"
    static let userToken                = "USER_TOKEN"
    static let userLogin                = "IS_USER_LOGIN"
    static let userKeepLogin            = "IS_KEEP_USER_LOGIN"
    static let userFullName             = "USER_FULL_NAME"
    static let userProfileImage         = "USER_PROFILE_IMAGE"
    static let userOnlineStatus         = "IS_USER_ONLINE"
    static let userPoints               = "USER_POINTS"
    static let device_id                = "DEVICE_ID"
    static let session_id               = "SESSION_ID"
    static let IS_FIRST_TIME_APP_RUN    = "IS_FIRST_TIME_APP_RUN"
    static let userID                   = "USER_ID"
    static let userProfilePath          = "USER_PROFILE_PATH"
    static let userEmail                = "USER_EMAIL"
    static let firebaseUID              = "FIREBASE_USER_ID"
    static let notification             = "NOTIFICATION_ON_OFF"
    static let allPostData              = "All_POST_GET"
    static let saveSelUserData          = "SELECT_USER_DATA"
}

class AppPrefsManager: NSObject
{

    static let shared = AppPrefsManager()
    
    
    // MARK: - IS FIRSTTIME APP RUN
    func setIsFirstTimeAppRunning(run: Bool) {
        setDataToPreference(data: run as AnyObject, forKey: AppPrefsKey.IS_FIRST_TIME_APP_RUN)
    }
    
    func isFirstTimeAppRunning() -> Bool {
        let isFirstTimeAppRunning = getDataFromPreference(key: AppPrefsKey.IS_FIRST_TIME_APP_RUN)
        return isFirstTimeAppRunning == nil ? true : (isFirstTimeAppRunning as! Bool)
    }
    
    func setDataToPreference(data: Any, forKey key: String) {
        let archivedData = NSKeyedArchiver.archivedData(withRootObject: data)
        UserDefaults.standard.set(archivedData, forKey: key)
        UserDefaults.standard.synchronize()
    }
    
    func getDataFromPreference(key: String) -> Any? {
        let archivedData = UserDefaults.standard.object(forKey: key)
        
        if(archivedData != nil) {
            return NSKeyedUnarchiver.unarchiveObject(with: archivedData! as! Data) as Any?
        }
        return nil
    }
    
    func removeDataFromPreference(key: String) {
        UserDefaults.standard.removeObject(forKey: key)
        UserDefaults.standard.synchronize()
    }
    
    func isKeyExistInPreference(key: String) -> Bool {
        if(UserDefaults.standard.object(forKey: key) == nil) {
            return false
        }
        
        return true
    }
        
    func resetAllUserInfo() {
        setIsUserLogin(isLogin: false)
        setIsUserOnline(isOnline: false)
        removeDataFromPreference(key: AppPrefsKey.userFullName)
        removeDataFromPreference(key: AppPrefsKey.userToken)
        removeDataFromPreference(key: AppPrefsKey.userPoints)
        removeDataFromPreference(key: AppPrefsKey.userProfileImage)
    }
    
    // MARK: - Set & Get Data
    private func setData<T: Codable>(data: T, forKey key: String) {
        do {
            let jsonData = try JSONEncoder().encode(data)
            UserDefaults.standard.set(jsonData, forKey: key)
            UserDefaults.standard.synchronize()
        } catch let error {
            print(error)
        }
    }
    
    private func getData<T: Codable>(objectType: T.Type, forKey key: String) -> T? {
        guard let result = UserDefaults.standard.data(forKey: key) else {
            return nil
        }
        do {
            return try JSONDecoder().decode(objectType, from: result)
        } catch let error {
            print(error)
            return nil
        }
    }
    
    // MARK: - Session Id
    func setSessionId(id: String) {
        setDataToPreference(data: id as AnyObject, forKey: AppPrefsKey.session_id)
    }
    
    func getSessionId() -> String {
        return getDataFromPreference(key: AppPrefsKey.session_id) as? String ?? ""
    }
    
    func removeSessionId() {
        removeDataFromPreference(key: AppPrefsKey.session_id)
    }
    
    //MARK: - User login
    func setIsUserLogin(isLogin: Bool) {
        setDataToPreference(data: isLogin, forKey: AppPrefsKey.userLogin)
    }
    
    func isUserLoggedIn() -> Bool {
        return getDataFromPreference(key: AppPrefsKey.userLogin) as? Bool ?? false
    }
    
    //MARK: - Keep User login
    func setIsKeepUserLogin(isLogin: Bool) {
        setDataToPreference(data: isLogin, forKey: AppPrefsKey.userKeepLogin)
    }
    
    func isUserKeepLoggedIn() -> Bool {
        return getDataFromPreference(key: AppPrefsKey.userKeepLogin) as? Bool ?? false
    }
    
    // MARK: - User Id
    func setUserId(id: Int) {
        setDataToPreference(data: id as Int, forKey: AppPrefsKey.userID)
    }
    
    func getUserId() -> Int {
        return getDataFromPreference(key: AppPrefsKey.userID) as? Int ?? 0
    }
    
    func removeUserId() {
        removeDataFromPreference(key: AppPrefsKey.userID)
    }
    
    // MARK: - User Profile Pic
    func setUserProfilePic(imagePath: String) {
        setDataToPreference(data: imagePath as String, forKey: AppPrefsKey.userProfilePath)
    }
    
    func getUserProfilePic() -> String {
        return getDataFromPreference(key: AppPrefsKey.userProfilePath) as? String ?? ""
    }
    
    func removeUserProfilePic() {
        removeDataFromPreference(key: AppPrefsKey.userProfilePath)
    }
    
    // MARK: - User Email
    func setUserEmail(email: String) {
        setDataToPreference(data: email as String, forKey: AppPrefsKey.userEmail)
    }
    
    func getUserEmail() -> String {
        return getDataFromPreference(key: AppPrefsKey.userEmail) as? String ?? ""
    }
    
    func removeUserEmail() {
        removeDataFromPreference(key: AppPrefsKey.userEmail)
    }
    
    // MARK: - Save User data
   /*
    func setUserData(model: SignInModel) {
        setData(data: model, forKey: KEY_LOGIN)
    }
    
    func getUserData() -> SignInModel? {
        return getData(objectType: SignInModel.self, forKey: KEY_LOGIN)
    }
    */
    
    func removeUserData() {
        removeDataFromPreference(key: KEY_LOGIN)
    }
    
    func removeUserDataByID() {
        removeDataFromPreference(key: AppPrefsKey.saveSelUserData)
    }
    
    //MARK: - FCM token
    func setFcmToken(token: String) {
        setDataToPreference(data: token, forKey: AppPrefsKey.fcmToken)
    }
    
    func getFcmToken() -> String {
        return getDataFromPreference(key: AppPrefsKey.fcmToken) as? String ?? ""
    }
    
    //MARK: - Token
    func setUserToken(token: String) {
        setDataToPreference(data: token, forKey: AppPrefsKey.userToken)
    }
    
    func getUserToken() -> String {
        return getDataFromPreference(key: AppPrefsKey.userToken) as? String ?? ""
    }
    
    //MARK: - Full Name
    func setUserFullName(fullName: String) {
        setDataToPreference(data: fullName, forKey: AppPrefsKey.userFullName)
    }
    
    func getUserFullName() -> String {
        return getDataFromPreference(key: AppPrefsKey.userFullName) as? String ?? ""
    }
    
    //MARK: - User Profile Image
    func setUserProfileImage(profileImage: String) {
        setDataToPreference(data: profileImage, forKey: AppPrefsKey.userProfileImage)
    }
    
    func getUserProfileImage() -> String {
        return getDataFromPreference(key: AppPrefsKey.userProfileImage) as? String ?? ""
    }
    
    //MARK: - User Online Status
    func setIsUserOnline(isOnline: Bool) {
        setDataToPreference(data: isOnline, forKey: AppPrefsKey.userOnlineStatus)
    }
    
    func isUserOnline() -> Bool {
        return getDataFromPreference(key: AppPrefsKey.userOnlineStatus) as? Bool ?? false
    }
    
    //MARK: - User points
    func setUserPoints(points: Int) {
        setDataToPreference(data: points, forKey: AppPrefsKey.userPoints)
    }
    
    func getUserPoints() -> Int {
        return getDataFromPreference(key: AppPrefsKey.userPoints) as? Int ?? 0
    }
    
    // MARK: - Device Id
    func setDeviceId(id: String) {
        setDataToPreference(data: id as AnyObject, forKey: AppPrefsKey.device_id)
    }
    
    func getDeviceId() -> String {
        return getDataFromPreference(key: AppPrefsKey.device_id) as? String ?? ""
    }
    
    func removeDeviceId() {
        removeDataFromPreference(key: AppPrefsKey.device_id)
    }
    
    // MARK: - Firebase uid
    func setFireBaseUId(id: String) {
        setDataToPreference(data: id as String, forKey: AppPrefsKey.firebaseUID)
    }
    
    func getFireBaseUId() -> String {
        return getDataFromPreference(key: AppPrefsKey.firebaseUID) as? String ?? ""
    }
    
    func removeFireBaseUId() {
        removeDataFromPreference(key: AppPrefsKey.firebaseUID)
    }
    
    // MARK: - Notification
    func setNotification(status: Bool) {
        setDataToPreference(data: status as Bool, forKey: AppPrefsKey.notification)
    }
    
    func getNotification() -> Bool {
        return getDataFromPreference(key: AppPrefsKey.notification) as? Bool ?? true
    }
    
    func removeNotification() {
        removeDataFromPreference(key: AppPrefsKey.notification)
    }
    
    //MARK:- Set Login and SignUp Root
    func setLoginSignUp1() {
        /*let rootVc = AppDelegate.shared.window?.rootViewController as! UINavigationController
        let nextVc = SignUpAndLogInViewController.instantiate(fromAppStoryboard: .Main)
        let nav = UINavigationController(rootViewController: nextVc)
        
        rootVc.present(nav, animated: true, completion: nil)*/
    }
    
    func intializeTabBar() {
        /*var window = AppDelegate.shared.window
        window = UIWindow(frame: UIScreen.main.bounds)
        
        let customTabBarController: CustomTabBarController = CustomTabBarController()
        
        let navVC = UINavigationController(rootViewController: customTabBarController)
        window?.backgroundColor = UIColor.white
        window?.rootViewController = navVC
        window?.makeKeyAndVisible()*/
    }
    
   
    //MARK:- Remove User Defaults
    func removeUserDefaults() {
        AppPrefsManager.shared.setIsUserLogin(isLogin: false)
        AppPrefsManager.shared.setIsKeepUserLogin(isLogin: false)
        AppPrefsManager.shared.removeSessionId()        
        AppPrefsManager.shared.removeUserData()
        AppPrefsManager.shared.removeUserId()
        AppPrefsManager.shared.removeUserProfilePic()
        AppPrefsManager.shared.removeUserEmail()
        AppPrefsManager.shared.removeFireBaseUId()
        AppPrefsManager.shared.removeNotification()
        AppPrefsManager.shared.removeUserDataByID()
    }
}


