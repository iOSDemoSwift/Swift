//
//  APIClient.swift


import Foundation
import Alamofire
import MBProgressHUD

class APIClient {
    
    private func callApi(apiURL: String, method: Alamofire.HTTPMethod, parameters: [String: Any]? = nil, headers: [String: String]? = nil, completion completionBlock: @escaping ([String : Any]?, Error?) -> Void, parameterEncoding: ParameterEncoding = JSONEncoding.default) -> DataRequest {
        
        return ApiManager.callApi(apiURL: apiURL, method: method, parameters: parameters, headers: headers, parameterEncoding: parameterEncoding, success: { (response, status) in
            DispatchQueue.main.async {
                let responseObj = response as? [String : Any]
                completionBlock(responseObj, nil)
            }
        }, failure: { (error, status) -> Bool in
            DLog(error, status)
            DispatchQueue.main.async {
                completionBlock(nil, error)
            }
            return true
        })
    }
    
    private func callApiWithUpload(apiURL: String, fileArr: [FileParameterRequest], method: Alamofire.HTTPMethod, parameters: [String: Any]? = nil, headers: [String: String]? = nil, completion completionBlock: @escaping ([String : Any]?, Error?) -> Void)  {
       
        ApiManager.callApiWithUpload(apiURL: apiURL, method: method, parameters: parameters, fileDataParameters: fileArr, headers: headers, success: { (response, status) in
            DispatchQueue.main.async {
                let responseObj = response as? [String : Any]
                completionBlock(responseObj, nil)
            }
        }, failure: { (error, status) -> Bool in
            DLog(error, status)
            DispatchQueue.main.async {
                completionBlock(nil, error)
            }
            return true
        })
    }
    
    //resturn statuscode
   private func callApi(apiURL: String, method: Alamofire.HTTPMethod, parameters: [String: Any]? = nil, headers: [String: String]? = nil, completion completionBlock: @escaping ([String : Any]?, Error?, Int?) -> Void, parameterEncoding: ParameterEncoding = JSONEncoding.default) -> DataRequest {
       return ApiManager.callApi(apiURL: apiURL, method: method, parameters: parameters, headers: headers, parameterEncoding: parameterEncoding, success: { (response, status) in
           DispatchQueue.main.async {
               let responseObj = response as? [String : Any]
               completionBlock(responseObj, nil, status)
           }
       }, failure: { (error, status) -> Bool in
           DLog(error, status)
           DispatchQueue.main.async {
               completionBlock(nil, error, status)
           }
           return true
       })
   }
   
   
   private func callApiArray(apiURL: String, method: Alamofire.HTTPMethod, parameters: [String: Any]? = nil, headers: [String: String]? = nil, completion completionBlock: @escaping ([[String : Any]]?, Error?) -> Void, parameterEncoding: ParameterEncoding = JSONEncoding.default) -> DataRequest {
       return ApiManager.callApi(apiURL: apiURL, method: method, parameters: parameters, headers: headers, parameterEncoding: parameterEncoding, success: { (response, status) in
           DispatchQueue.main.async {
               let responseObj = response as? [[String : Any]]
               completionBlock(responseObj, nil)
           }
       }, failure: { (error, status) -> Bool in
           DLog(error, status)
           DispatchQueue.main.async {
               completionBlock(nil, error)
           }
           return true
       })
   }
    
    //URLSession
    func callDataTaskAPI(url: URL, method: String, headers: [String: String], completion completionBlock: @escaping ([Any]?, Error?, Int?) -> Void)
    {
        var request = URLRequest(url: url)
        
        request.httpMethod = method
        request.allHTTPHeaderFields = headers
        
        let session = URLSession.shared
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            
            do {
                if (error != nil) {
                    completionBlock(nil, error, 401)
                } else {
                    //Send redable json
                    let httpResponse = response as? HTTPURLResponse
                    let result = try JSONSerialization.jsonObject(with: data!, options: [])
                    DLog(result)
                    //                print(httpResponse)
                    completionBlock(result as? [Any], nil, httpResponse?.statusCode)
                    
                    //OR
                    // send data
//                    let httpResponse = response as? HTTPURLResponse
//                    complitionBloack(data!, nil, httpResponse?.statusCode)
                }
            } catch let error {
                DLog(error.localizedDescription)
                completionBlock(nil, error, 401)
            }
            
        })
        
        dataTask.resume()
    }
    
    // Authentication
    /*
    func login(parameters: ParameterRequest, completion completionBlock: @escaping ([String : Any]?, Error?) -> Void) -> DataRequest {
        let headerReq = HeaderRequestParameter()
        return callApi(apiURL: API.LOGIN, method: .post, parameters: parameters.parameters, headers: headerReq.parameters, completion: completionBlock)
    }
    
    func register(parameters: ParameterRequest, fileArray: [FileParameterRequest], completion completionBlock: @escaping ([String : Any]?, Error?) -> Void) {
        let headerReq = HeaderRequestParameter()
        return callApiWithUpload(apiURL: API.REGISTER, fileArr: fileArray, method: .post, parameters: parameters.parameters, headers: headerReq.parameters, completion: completionBlock)
    }
 */
}
